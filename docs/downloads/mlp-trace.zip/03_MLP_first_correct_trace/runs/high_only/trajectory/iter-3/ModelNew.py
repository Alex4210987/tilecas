import tilelang
import tilelang.language as T
from reference import nn


@tilelang.jit(out_idx=[-1], target='ascendc')
def convert(R, C):
    B = 16384
    @T.prim_func
    def kernel(X: T.Tensor((R*C,), 'float32'), Y: T.Tensor((R*C,), 'float16')):
        with T.Kernel(24, is_npu=True) as (bid, vid):
            a = T.alloc_ub((B,), 'float32')
            b = T.alloc_ub((B,), 'float16')
            with T.Scope('V'):
                for j in T.serial(T.ceildiv(R*C,48*B)):
                    pos=(j*48+bid*2+vid)*B
                    if pos < R*C:
                        T.copy(X[pos], a)
                        T.barrier_all()
                        T.copy(a, b)
                        T.barrier_all()
                        T.copy(b, Y[pos])
                        T.barrier_all()
    return kernel


@tilelang.jit(out_idx=[-1], target='ascendc', pass_configs={tilelang.PassConfigKey.TL_ASCEND_AUTO_SYNC: True})
def product(M, N, K, BN=128, BK=256):
    BM = 128
    @T.prim_func
    def kernel(A: T.Tensor((M,K), 'float16'), W: T.Tensor((N,K), 'float16'), C: T.Tensor((M,N), 'float32')):
        with T.Kernel(N//BN, is_npu=True) as (bid, _):
            a = T.alloc_L1((BM,BK), 'float16')
            b = T.alloc_L1((BN,BK), 'float16')
            c = T.alloc_L0C((BM,BN), 'float32')
            with T.Scope('C'):
                for k in T.Pipelined(K//BK, num_stages=2):
                    T.copy(A[0,k*BK], a)
                    T.copy(W[bid*BN,k*BK], b)
                    T.gemm_v0(a,b,c,transpose_B=True,init=(k==0))
                T.copy(c,C[0,bid*BN])
    return kernel


@tilelang.jit(out_idx=[-1], target='ascendc')
def epilogue(M,N,activate):
    B=1024
    @T.prim_func
    def kernel(X:T.Tensor((M,N),'float32'), Bias:T.Tensor((N,),'float32'), Y:T.Tensor((M,N),'float32')):
        with T.Kernel(M*N//(2*B),is_npu=True) as (bid,vid):
            a=T.alloc_ub((B,), 'float32')
            b=T.alloc_ub((B,), 'float32')
            with T.Scope('V'):
                row=(bid*2+vid)//(N//B)
                col=(bid*2+vid)%(N//B)*B
                T.copy(X[row,col],a)
                T.copy(Bias[col],b)
                T.barrier_all()
                for i in T.Parallel(B):
                    a[i]=a[i]+b[i]
                if activate:
                    for i in T.Parallel(B):
                        a[i]=T.max(a[i],0.0)
                T.barrier_all()
                T.copy(a,Y[row,col])
    return kernel


class ModelNew(nn.Module):
    def __init__(self,input_size,layer_sizes,output_size):
        super().__init__()
        layers=[]
        previous=input_size
        for size in layer_sizes:
            layers.extend([nn.Linear(previous,size),nn.ReLU()])
            previous=size
        layers.append(nn.Linear(previous,output_size))
        self.network=nn.Sequential(*layers)

    def forward(self,x):
        for index in range(0,len(self.network),2):
            layer=self.network[index]
            n,k=layer.weight.shape
            a=convert(128,k)(x.view(-1)).view(128,k)
            w=convert(n,k)(layer.weight.view(-1)).view(n,k)
            c=product(128,n,k)(a,w)
            x=epilogue(128,n,index+1<len(self.network))(c,layer.bias)
        return x
