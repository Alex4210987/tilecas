#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void kernel_kernel( GM_ADDR X_handle,  GM_ADDR Y_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<float> X;
  X.SetGlobalBuffer((__gm__ float*)X_handle);
  AscendC::GlobalTensor<half> Y;
  Y.SetGlobalBuffer((__gm__ half*)Y_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 131072);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 196352);
  pipe.Destroy();
  auto bid = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    bid = bid / 2;
  }
  auto a = ascend_ub.GetWithOffset<float>(4096, 0);
  auto b = ascend_ub.GetWithOffset<half>(4096, 16384);
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIV {
    tl::ascend::copy_gm_to_ub<float, 4096>(a[0], X[((bid * 8192) + (vid * 4096))], 2097152, 1, 4096, 0.000000e+00f);
    AscendC::PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_ub_to_ub<half, float, 4096>(b[0], a[0], 1, 4096, 4096, 1, 4096, 4096);
    AscendC::PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_ub_to_gm<half, 4096>(Y[((bid * 8192) + (vid * 4096))], b[0], 2097152, 1, 4096);
  }
}

void kernel_kernel_tiling() {
}

extern "C" void call(uint8_t* X_handle, uint8_t* Y_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  kernel_kernel_tiling();
  kernel_kernel<<<256, nullptr, stream>>>(X_handle, Y_handle, fftsAddr);
}
