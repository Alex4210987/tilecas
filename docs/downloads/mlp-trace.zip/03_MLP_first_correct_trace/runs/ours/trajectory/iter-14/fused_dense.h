#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using namespace AscendC;
constexpr int M = 128, N = OUT_N, K = 16384, BN = 128, BK = 512, VR = 32, PARTS = BN / 2 / VR;

extern "C" __global__ __aicore__ void fused_dense(GM_ADDR ap, GM_ADDR wp, GM_ADDR cp, GM_ADDR sp, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  SetSyncBaseAddr(fftsAddr);
  TPipe pipe;
  GlobalTensor<half> A; A.SetGlobalBuffer((__gm__ half*)ap);
  GlobalTensor<float> W; W.SetGlobalBuffer((__gm__ float*)wp);
  GlobalTensor<half> S; S.SetGlobalBuffer((__gm__ half*)sp);
  GlobalTensor<float> C; C.SetGlobalBuffer((__gm__ float*)cp);
  TBuf<TPosition::A2> l0a; pipe.InitBuffer(l0a, 65536);
  TBuf<TPosition::B2> l0b; pipe.InitBuffer(l0b, 65536);
  TBuf<TPosition::CO1> l0c; pipe.InitBuffer(l0c, 131072);
  TBuf<TPosition::A1> l1; pipe.InitBuffer(l1, 524288);
  TBuf<TPosition::VECCALC> ub; pipe.InitBuffer(ub, 196352);
  pipe.Destroy();
  int cid = GetBlockIdx();
  if ASCEND_IS_AIV { cid /= 2; }
  int vid = GetSubBlockIdx();
  auto al = l1.GetWithOffset<half>(2 * M * BK, 0);
  auto bl = l1.GetWithOffset<half>(2 * BN * BK, 2 * M * BK * 2);
  auto cl = l0c.GetWithOffset<float>(M * BN, 0);
  auto wf = ub.GetWithOffset<float>(2 * VR * BK, 0);
  auto wh = ub.GetWithOffset<half>(VR * BK, 2 * VR * BK * 4);
  if ASCEND_IS_AIC {
    constexpr int KL0 = 128;
    auto aa = l0a.Get<half>();
    auto bb = l0b.Get<half>();
    SetFlag<HardEvent::M_MTE1>(0);
    SetFlag<HardEvent::M_MTE1>(1);
    CrossCoreSetFlag<2, PIPE_MTE1>(2);
    CrossCoreSetFlag<2, PIPE_MTE1>(3);
    tl::ascend::copy_gm_to_l1<half, M, BK>(al, A[0], K, M, BK, false);
    CrossCoreWaitFlag<2>(0);
    tl::ascend::copy_gm_to_l1<half, BN, BK>(bl, S[cid * 2 * BN * BK], BK, BN, BK, false);
    SetFlag<HardEvent::MTE2_MTE1>(2);
    CrossCoreSetFlag<2, PIPE_MTE2>(2);
    for (int k = 0; k < K / BK; ++k) {
      int slot = k % 2;
      WaitFlag<HardEvent::MTE2_MTE1>(2 + slot);
      for (int kk = 0; kk < BK / KL0; ++kk) {
        int pp = kk % 2;
        WaitFlag<HardEvent::M_MTE1>(pp);
        tl::ascend::copy_l1_to_l0a<half, M, BK>(aa[pp * M * KL0], al[slot * M * BK + kk * M * KL0], M, KL0);
        tl::ascend::copy_l1_to_l0b<half, BN, BK, true>(bb[pp * BN * KL0], bl[slot * BN * BK + kk * BN * KL0], KL0, BN);
        SetFlag<HardEvent::MTE1_M>(pp);
        WaitFlag<HardEvent::MTE1_M>(pp);
        PipeBarrier<PIPE_M>();
        tl::ascend::mma<half, float, M, BN>(aa[pp * M * KL0], bb[pp * BN * KL0], cl, k == 0 && kk == 0, KL0);
        SetFlag<HardEvent::M_MTE1>(pp);
      }
      if (k + 1 < K / BK) {
        int next = (k + 1) % 2;
        SetFlag<HardEvent::MTE1_MTE2>(2 + next);
        WaitFlag<HardEvent::MTE1_MTE2>(2 + next);
        tl::ascend::copy_gm_to_l1<half, M, BK>(al[next * M * BK], A[(k + 1) * BK], K, M, BK, false);
        CrossCoreWaitFlag<2>(next);
        tl::ascend::copy_gm_to_l1<half, BN, BK>(bl[next * BN * BK], S[(cid * 2 + next) * BN * BK], BK, BN, BK, false);
        SetFlag<HardEvent::MTE2_MTE1>(2 + next);
        CrossCoreSetFlag<2, PIPE_MTE2>(2 + next);
      }
    }
    WaitFlag<HardEvent::M_MTE1>(0);
    WaitFlag<HardEvent::M_MTE1>(1);
    SetFlag<HardEvent::M_FIX>(0);
    WaitFlag<HardEvent::M_FIX>(0);
    tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, M, BN, 0>(C[cid * BN], cl, N, M, BN, 0);
  }
  if ASCEND_IS_AIV {
    constexpr int VLEN = VR * BK;
    constexpr int STEPS = K / BK * PARTS;
    SetFlag<HardEvent::V_MTE2>(1);
    SetFlag<HardEvent::MTE3_V>(2);
    tl::ascend::copy_gm_to_ub<float, BK, VR>(wf, W[(cid * BN + vid * (BN / 2)) * K], K, VR, BK);
    SetFlag<HardEvent::MTE2_V>(0);
    for (int t = 0; t < STEPS; ++t) {
      int k = t / PARTS, q = t % PARTS, slot = t % 2;
      WaitFlag<HardEvent::MTE2_V>(slot);
      if (t + 1 < STEPS) {
        int next = (t + 1) % 2;
        int nk = (t + 1) / PARTS, nq = (t + 1) % PARTS;
        WaitFlag<HardEvent::V_MTE2>(next);
        tl::ascend::copy_gm_to_ub<float, BK, VR>(wf[next * VLEN], W[(cid * BN + vid * (BN / 2) + nq * VR) * K + nk * BK], K, VR, BK);
        SetFlag<HardEvent::MTE2_V>(next);
      }
      if (q == 0) CrossCoreWaitFlag<2>(2 + k % 2);
      WaitFlag<HardEvent::MTE3_V>(2);
      Cast(wh, wf[slot * VLEN], RoundMode::CAST_NONE, VLEN);
      SetFlag<HardEvent::V_MTE2>(slot);
      SetFlag<HardEvent::V_MTE3>(2);
      WaitFlag<HardEvent::V_MTE3>(2);
      tl::ascend::copy_ub_to_gm<half, BK, VR>(S[(cid * 2 + k % 2) * BN * BK + (vid * (BN / 2) + q * VR) * BK], wh, BK, VR, BK);
      SetFlag<HardEvent::MTE3_V>(2);
      if (q == PARTS - 1) CrossCoreSetFlag<2, PIPE_MTE3>(k % 2);
    }
    WaitFlag<HardEvent::V_MTE2>(0);
    WaitFlag<HardEvent::V_MTE2>(1);
    WaitFlag<HardEvent::MTE3_V>(2);
    CrossCoreWaitFlag<2>(2);
    CrossCoreWaitFlag<2>(3);
  }

}
extern "C" void call(uint8_t* a, uint8_t* w, uint8_t* c, uint8_t* s, aclrtStream stream) {
  uint32_t len = 0; uint64_t addr = 0;
  rtGetC2cCtrlAddr(&addr, &len);
  fused_dense<<<N / BN, nullptr, stream>>>(a, w, c, s, addr);
}
