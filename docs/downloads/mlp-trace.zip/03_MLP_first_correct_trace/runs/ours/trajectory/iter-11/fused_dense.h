#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using namespace AscendC;
constexpr int M = 128, N = OUT_N, K = 16384, BN = 128, BK = 256, STAGES = 1;

extern "C" __global__ __aicore__ void hf32_dense(GM_ADDR ap, GM_ADDR wp, GM_ADDR cp, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  TPipe pipe;
  GlobalTensor<float> A; A.SetGlobalBuffer((__gm__ float*)ap);
  GlobalTensor<float> W; W.SetGlobalBuffer((__gm__ float*)wp);
  GlobalTensor<float> C; C.SetGlobalBuffer((__gm__ float*)cp);
  TBuf<TPosition::A2> l0a; pipe.InitBuffer(l0a, 65536);
  TBuf<TPosition::B2> l0b; pipe.InitBuffer(l0b, 65536);
  TBuf<TPosition::CO1> l0c; pipe.InitBuffer(l0c, 131072);
  TBuf<TPosition::A1> l1; pipe.InitBuffer(l1, 524032);
  pipe.Destroy();
  int cid = GetBlockIdx();
  if ASCEND_IS_AIV { cid /= 2; }
  auto al = l1.GetWithOffset<float>(STAGES * M * BK, 0);
  auto bl = l1.GetWithOffset<float>(STAGES * BN * BK, STAGES * M * BK * 4);
  auto cl = l0c.GetWithOffset<float>(M * BN, 0);
  if ASCEND_IS_AIC {
    SetHF32Mode(true);
    SetHF32TransMode(false);
    for (int s = 0; s < STAGES; ++s) {
      tl::ascend::copy_gm_to_l1<float, M, BK>(al[s * M * BK], A[s * BK], K, M, BK, false);
      tl::ascend::copy_gm_to_l1<float, BN, BK>(bl[s * BN * BK], W[cid * BN * K + s * BK], K, BN, BK, false);
    }
    for (int k = 0; k < K / BK; ++k) {
      PipeBarrier<PIPE_ALL>();
      tl::ascend::gemm_v0<float, float, M, BN, BK, false, true, 64>(al[k % STAGES * M * BK], bl[k % STAGES * BN * BK], cl, l0a, l0b, k == 0);
      if (k + STAGES < K / BK) {
        tl::ascend::copy_gm_to_l1<float, M, BK>(al[k % STAGES * M * BK], A[(k + STAGES) * BK], K, M, BK, false);
        tl::ascend::copy_gm_to_l1<float, BN, BK>(bl[k % STAGES * BN * BK], W[cid * BN * K + (k + STAGES) * BK], K, BN, BK, false);
      }
    }
    PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, M, BN, 0>(C[cid * BN], cl, N, M, BN, 0);
    SetHF32Mode(false);
  }
}
extern "C" void call(uint8_t* a, uint8_t* w, uint8_t* c, aclrtStream stream) {
  uint32_t len = 0; uint64_t addr = 0;
  rtGetC2cCtrlAddr(&addr, &len);
  hf32_dense<<<N / BN, nullptr, stream>>>(a, w, c, addr);
}
