#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using namespace AscendC;
constexpr int M = 128, N = OUT_N, K = 16384, BN = 128, BK = 256, STAGES = 2;

extern "C" __global__ __aicore__ void hf32_dense(GM_ADDR ap, GM_ADDR wp, GM_ADDR cp, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  TPipe pipe;
  GlobalTensor<float> A; A.SetGlobalBuffer((__gm__ float*)ap);
  GlobalTensor<float> W; W.SetGlobalBuffer((__gm__ float*)wp);
  GlobalTensor<float> C; C.SetGlobalBuffer((__gm__ float*)cp);
  TBuf<TPosition::A2> l0a; pipe.InitBuffer(l0a, 65536);
  TBuf<TPosition::B2> l0b; pipe.InitBuffer(l0b, 65536);
  TBuf<TPosition::CO1> l0c; pipe.InitBuffer(l0c, 131072);
  TBuf<TPosition::A1> l1; pipe.InitBuffer(l1, 524288);
  pipe.Destroy();
  int cid = GetBlockIdx();
  if ASCEND_IS_AIV { cid /= 2; }
  auto al = l1.GetWithOffset<float>(STAGES * M * BK, 0);
  auto bl = l1.GetWithOffset<float>(STAGES * BN * BK, STAGES * M * BK * 4);
  auto cl = l0c.GetWithOffset<float>(M * BN, 0);
  if ASCEND_IS_AIC {
    SetHF32Mode(true);
    SetHF32TransMode(false);
    auto aa = l0a.Get<float>();
    auto bb = l0b.Get<float>();
    constexpr int KL0 = 64;
    SetFlag<HardEvent::M_MTE1>(0);
    SetFlag<HardEvent::M_MTE1>(1);
    for (int s = 0; s < STAGES; ++s) {
      tl::ascend::copy_gm_to_l1<float, M, BK>(al[s * M * BK], A[s * BK], K, M, BK, false);
      tl::ascend::copy_gm_to_l1<float, BN, BK>(bl[s * BN * BK], W[cid * BN * K + s * BK], K, BN, BK, false);
      SetFlag<HardEvent::MTE2_MTE1>(2 + s);
    }
    for (int k = 0; k < K / BK; ++k) {
      int slot = k % STAGES;
      WaitFlag<HardEvent::MTE2_MTE1>(2 + slot);
      for (int kk = 0; kk < BK / KL0; ++kk) {
        int pp = kk % 2;
        WaitFlag<HardEvent::M_MTE1>(pp);
        tl::ascend::copy_l1_to_l0a<float, M, BK>(aa[pp * M * KL0], al[slot * M * BK + kk * M * KL0], M, KL0);
        tl::ascend::copy_l1_to_l0b<float, BN, BK, true>(bb[pp * BN * KL0], bl[slot * BN * BK + kk * BN * KL0], KL0, BN);
        SetFlag<HardEvent::MTE1_M>(pp);
        WaitFlag<HardEvent::MTE1_M>(pp);
        PipeBarrier<PIPE_M>();
        tl::ascend::mma<float, float, M, BN>(aa[pp * M * KL0], bb[pp * BN * KL0], cl, k == 0 && kk == 0, KL0);
        SetFlag<HardEvent::M_MTE1>(pp);
      }
      if (k + STAGES < K / BK) {
        SetFlag<HardEvent::MTE1_MTE2>(2 + slot);
        WaitFlag<HardEvent::MTE1_MTE2>(2 + slot);
        tl::ascend::copy_gm_to_l1<float, M, BK>(al[slot * M * BK], A[(k + STAGES) * BK], K, M, BK, false);
        tl::ascend::copy_gm_to_l1<float, BN, BK>(bl[slot * BN * BK], W[cid * BN * K + (k + STAGES) * BK], K, BN, BK, false);
        SetFlag<HardEvent::MTE2_MTE1>(2 + slot);
      }
    }
    WaitFlag<HardEvent::M_MTE1>(0);
    WaitFlag<HardEvent::M_MTE1>(1);
    SetFlag<HardEvent::M_FIX>(0);
    WaitFlag<HardEvent::M_FIX>(0);
    tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, M, BN, 0>(C[cid * BN], cl, N, M, BN, 0);
    SetHF32Mode(false);
  }
}
extern "C" void call(uint8_t* a, uint8_t* w, uint8_t* c, aclrtStream stream) {
  uint32_t len = 0; uint64_t addr = 0;
  rtGetC2cCtrlAddr(&addr, &len);
  hf32_dense<<<N / BN, nullptr, stream>>>(a, w, c, addr);
}
