#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
using namespace AscendC;
extern "C" __global__ __aicore__ void zero_output(GM_ADDR cp) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  TPipe pipe;
  TBuf<TPosition::VECCALC> ub; pipe.InitBuffer(ub, 16384);
  auto z = ub.Get<float>();
  GlobalTensor<float> C; C.SetGlobalBuffer((__gm__ float*)cp);
  if ASCEND_IS_AIV {
    Duplicate(z, 0.0f, 4096);
    PipeBarrier<PIPE_ALL>();
    for (int t = GetBlockIdx(); t < 128 * OUT_N / 4096; t += 40) {
      tl::ascend::copy_ub_to_gm<float, 4096>(C[t * 4096], z, 128 * OUT_N, 1, 4096);
    }
    PipeBarrier<PIPE_ALL>();
  }
}
extern "C" void call(uint8_t* c, aclrtStream stream) {
  zero_output<<<20, nullptr, stream>>>(c);
}
