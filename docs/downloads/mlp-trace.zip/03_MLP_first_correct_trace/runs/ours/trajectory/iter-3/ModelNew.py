import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from reference import Model
import tilelang
import tilelang.language as T

@tilelang.jit(out_idx=[-1])
def convert(R, C):
    B = 8192
    @T.prim_func
    def main(X: T.Tensor((R, C), 'float32'), Y: T.Tensor((R, C), 'float16')):
        with T.Kernel(R * C // (2 * B), is_npu=True) as (cid, vid):
            x = T.alloc_ub((B,), 'float32')
            y = T.alloc_ub((B,), 'float16')
            with T.Scope('V'):
                offset = (cid * 2 + vid) * B
                T.copy(X[offset // C, offset % C], x)
                T.barrier_all()
                T.tile.cast(y, x, 'CAST_NONE', B)
                T.barrier_all()
                T.copy(y, Y[offset // C, offset % C])
    return main

@tilelang.jit(out_idx=[-1])
def dense(M, N, K):
    BM, BN, BK = 128, 128, 256
    @T.prim_func
    def main(A: T.Tensor((M, K), 'float16'), W: T.Tensor((N, K), 'float16'), C: T.Tensor((M, N), 'float32')):
        with T.Kernel((M // BM) * (N // BN), is_npu=True) as (cid, vid):
            al = T.alloc_L1((BM, BK), 'float16')
            bl = T.alloc_L1((BN, BK), 'float16')
            cl = T.alloc_L0C((BM, BN), 'float32')
            with T.Scope('C'):
                for k in T.Pipelined(K // BK, num_stages=3):
                    T.copy(A[cid // (N // BN) * BM, k * BK], al)
                    T.copy(W[cid % (N // BN) * BN, k * BK], bl)
                    T.barrier_all()
                    T.gemm_v0(al, bl, cl, transpose_B=True, init=(k == 0))
                    T.barrier_all()
                T.copy(cl, C[cid // (N // BN) * BM, cid % (N // BN) * BN])
    return main

@tilelang.jit(out_idx=[-1])
def epilogue(M, N, relu, dtype):
    B = 4096
    @T.prim_func
    def main(X: T.Tensor((M, N), 'float32'), Bias: T.Tensor((N,), 'float32'), Y: T.Tensor((M, N), dtype)):
        with T.Kernel(M * N // (2 * B), is_npu=True) as (cid, vid):
            x = T.alloc_ub((B,), 'float32')
            b = T.alloc_ub((B,), 'float32')
            y = T.alloc_ub((B,), dtype)
            with T.Scope('V'):
                offset = (cid * 2 + vid) * B
                T.copy(X[offset // N, offset % N], x)
                T.copy(Bias[offset % N], b)
                T.barrier_all()
                T.tile.add(x, x, b)
                T.barrier_all()
                if relu:
                    T.tile.max(x, x, 0.0)
                    T.barrier_all()
                if dtype == 'float16':
                    T.tile.cast(y, x, 'CAST_NONE', B)
                else:
                    T.copy(x, y)
                T.barrier_all()
                T.copy(y, Y[offset // N, offset % N])
    return main

class ModelNew(Model):
    def forward(self, x):
        x = convert(128, self.network[0].in_features)(x)
        for idx in (0, 2, 4):
            layer = self.network[idx]
            n, k = layer.out_features, layer.in_features
            w = convert(n, k)(layer.weight)
            x = dense(128, n, k)(x, w)
            x = epilogue(128, n, idx != 4, 'float16' if idx != 4 else 'float32')(x, layer.bias)
        return x
