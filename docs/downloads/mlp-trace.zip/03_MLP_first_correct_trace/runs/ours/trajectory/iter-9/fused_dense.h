#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using namespace AscendC;
constexpr int M = 128, N = OUT_N, K = 16384, BN = 128, BK = 256;

extern "C" __global__ __aicore__ void fused_dense(GM_ADDR ap, GM_ADDR wp, GM_ADDR cp, GM_ADDR sp, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  SetSyncBaseAddr(fftsAddr);
  TPipe pipe;
  GlobalTensor<half> A; A.SetGlobalBuffer((__gm__ half*)ap);
  GlobalTensor<float> W; W.SetGlobalBuffer((__gm__ float*)wp);
  GlobalTensor<half> S; S.SetGlobalBuffer((__gm__ half*)sp);
  GlobalTensor<float> C; C.SetGlobalBuffer((__gm__ float*)cp);
  TBuf<TPosition::A2> l0a; pipe.InitBuffer(l0a, 65536);
  TBuf<TPosition::B2> l0b; pipe.InitBuffer(l0b, 65536);
  TBuf<TPosition::CO1> l0c; pipe.InitBuffer(l0c, 131072);
  TBuf<TPosition::A1> l1; pipe.InitBuffer(l1, 524032);
  TBuf<TPosition::VECCALC> ub; pipe.InitBuffer(ub, 196352);
  pipe.Destroy();
  int cid = GetBlockIdx();
  if ASCEND_IS_AIV { cid /= 2; }
  int vid = GetSubBlockIdx();
  auto al = l1.GetWithOffset<half>(M * BK, 0);
  auto bl = l1.GetWithOffset<half>(2 * BN * BK, M * BK * 2);
  auto cl = l0c.GetWithOffset<float>(M * BN, 0);
  auto wf = ub.GetWithOffset<float>(2 * BN / 2 * BK, 0);
  auto wh = ub.GetWithOffset<half>(BN / 2 * BK, 2 * BN / 2 * BK * 4);
  if ASCEND_IS_AIC {
    CrossCoreSetFlag<2, PIPE_MTE1>(2);
    CrossCoreSetFlag<2, PIPE_MTE1>(3);
    for (int k = 0; k < K / BK; ++k) {
      tl::ascend::copy_gm_to_l1<half, M, BK>(al, A[k * BK], K, M, BK, false);
      PipeBarrier<PIPE_ALL>();
      CrossCoreWaitFlag<2>(k % 2);
      tl::ascend::copy_gm_to_l1<half, BN, BK>(bl[k % 2 * BN * BK], S[(cid * 2 + k % 2) * BN * BK], BK, BN, BK, false);
      PipeBarrier<PIPE_ALL>();
      tl::ascend::gemm_v0<half, float, M, BN, BK, false, true, 128>(al, bl[k % 2 * BN * BK], cl, l0a, l0b, k == 0);
      PipeBarrier<PIPE_ALL>();
      CrossCoreSetFlag<2, PIPE_MTE1>(2 + k % 2);
    }
    tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, M, BN, 0>(C[cid * BN], cl, N, M, BN, 0);
  }
  if ASCEND_IS_AIV {
    constexpr int VLEN = BN / 2 * BK;
    SetFlag<HardEvent::V_MTE2>(1);
    SetFlag<HardEvent::MTE3_V>(2);
    tl::ascend::copy_gm_to_ub<float, BK, BN / 2>(wf, W[(cid * BN + vid * (BN / 2)) * K], K, BN / 2, BK);
    SetFlag<HardEvent::MTE2_V>(0);
    for (int k = 0; k < K / BK; ++k) {
      int slot = k % 2;
      WaitFlag<HardEvent::MTE2_V>(slot);
      if (k + 1 < K / BK) {
        int next = (k + 1) % 2;
        WaitFlag<HardEvent::V_MTE2>(next);
        tl::ascend::copy_gm_to_ub<float, BK, BN / 2>(wf[next * VLEN], W[(cid * BN + vid * (BN / 2)) * K + (k + 1) * BK], K, BN / 2, BK);
        SetFlag<HardEvent::MTE2_V>(next);
      }
      CrossCoreWaitFlag<2>(2 + slot);
      WaitFlag<HardEvent::MTE3_V>(2);
      Cast(wh, wf[slot * VLEN], RoundMode::CAST_NONE, VLEN);
      SetFlag<HardEvent::V_MTE2>(slot);
      SetFlag<HardEvent::V_MTE3>(2);
      WaitFlag<HardEvent::V_MTE3>(2);
      tl::ascend::copy_ub_to_gm<half, BK, BN / 2>(S[(cid * 2 + slot) * BN * BK + vid * VLEN], wh, BK, BN / 2, BK);
      SetFlag<HardEvent::MTE3_V>(2);
      CrossCoreSetFlag<2, PIPE_MTE3>(slot);
    }
    WaitFlag<HardEvent::V_MTE2>(0);
    WaitFlag<HardEvent::V_MTE2>(1);
    WaitFlag<HardEvent::MTE3_V>(2);
    CrossCoreWaitFlag<2>(2);
    CrossCoreWaitFlag<2>(3);
  }

}
extern "C" void call(uint8_t* a, uint8_t* w, uint8_t* c, uint8_t* s, aclrtStream stream) {
  uint32_t len = 0; uint64_t addr = 0;
  rtGetC2cCtrlAddr(&addr, &len);
  fused_dense<<<N / BN, nullptr, stream>>>(a, w, c, s, addr);
}
