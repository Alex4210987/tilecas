from pathlib import Path
import importlib.util
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from reference import Model as ReferenceModel

class ModelNew(ReferenceModel):
    # Inherit initialization/state management only; all forward computation
    # executes the exported native kernels, including weight conversions.
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        root = Path(__file__).resolve().parent
        spec = importlib.util.spec_from_file_location("native_runtime", root / "runtime.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.runtime = module.Runtime(root)
    def forward(self, *args):
        return self.runtime.forward(*args, state_owner=self)
