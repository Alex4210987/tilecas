#define APPLY_RELU 0
#define VECTOR_B 8192
#define NEXT_N 16384
#include "vector_stages.h"
