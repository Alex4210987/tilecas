#define OUT_N 16384
#include "fused_dense.h"
