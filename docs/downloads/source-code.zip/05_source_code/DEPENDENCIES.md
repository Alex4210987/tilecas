# Dependencies and source setup

This directory includes workflow source resources. Hardware SDKs and model services remain external. The MLP and MinGPT directories contain candidate source and five-sample timing records; their protocol is in `../00_paper_protocol/CASE_PROTOCOLS.md`.

## Bundled resources

| Required location | Supplied content | Project |
|---|---|---|
| `thirdparty/KernelBench/KernelBench/level3/` | All 50 Level-3 workload references; floating `torch.rand`/`rand_like` input calls adapted to N(0,1) | [KernelBench](https://github.com/ScalingIntelligence/KernelBench) |
| `thirdparty/KernelBench/src/` | Ascend evaluation adapter and package support; license and upstream dependency manifests also included | [KernelBench](https://github.com/ScalingIntelligence/KernelBench) |
| `thirdparty/AKO4ALL/` | Skill, iteration template, hints and benchmark support; license retained | [AKO4ALL](https://github.com/TongmingLAIC/AKO4ALL) |
| `knowledge/ako4all/` | Concrete copies of the policy/template required by the Ascend launcher | Same AKO4ALL source |
| `KDA_REFERENCE.md` | Fixed upstream links, download steps, and dedicated local launcher instructions | [KDA source revision](https://github.com/NVlabs/kda/tree/ef6ce617693ef0782b3ecb9f37e39bbf10226a90) |
| `knowledge/ascend/`, `knowledge/rocm/` | Official resource-link indexes; SDK headers/examples come from the host installation | Links below |

These are local source copies, not claims of an immutable upstream release. The KernelBench bundle is scoped to the paper's Level-3 tasks; Levels 1, 2 and 4, stored benchmark results, notebooks, build caches and illustration assets are omitted. `BUNDLED_DEPENDENCIES.json` lists copied files and the workload files adapted to standard-normal floating inputs. No experimental results, credentials, Git history or model weights were copied with these dependencies.

## Platform installations

Version targets below are copied from `../01_software_details/software_versions.csv`. They describe the recorded case environments, not a verified public installation lockfile. Public latest releases may differ; custom builds may require the original environment provider.

| Component | Case environment target | Official source / installation documentation |
|---|---|---|
| ROCm SDK | 7.14.1 | [ROCm documentation](https://rocm.docs.amd.com/en/latest/) |
| HIP | 7.14.60850-0000000 | [HIP documentation](https://rocm.docs.amd.com/projects/HIP/en/latest/) |
| AMD PyTorch | 2.14.0+rocm7.14 | [PyTorch installation selector](https://pytorch.org/get-started/locally/) |
| AMD TileLang | 0.1.14 | [TileLang](https://github.com/tile-ai/tilelang) |
| CANN / Ascend C | CANN 9.0.0 | [CANN downloads](https://www.hiascend.com/developer/download/community/result?module=cann) |
| Ascend PyTorch | 2.7.1 | [PyTorch](https://pytorch.org/get-started/locally/) and [Ascend adapter compatibility instructions](https://github.com/Ascend/pytorch) |
| torch_npu | 2.7.1.post4 | [Ascend PyTorch adapter](https://github.com/Ascend/pytorch) |
| TileLang-Ascend | Source 0.1.4; recorded wheel 0.1.4+ubuntu.20.4.cann900 | [TileLang-Ascend build instructions](https://github.com/tile-ai/tilelang-ascend) |
| ROCm diagnostic profiler | Match installed ROCm toolkit | [ROCprofiler-SDK](https://rocm.docs.amd.com/projects/rocprofiler-sdk/en/latest/) |

Use separate AMD and Ascend Python environments and the corresponding compiler, device driver and profiler. The recorded Ascend environment uses Python 3.11; the AMD environment uses Python 3.12. The bundled upstream KernelBench manifest currently pins a different Python/framework stack and includes CUDA-specific extras; it is retained for reference, not as a replacement for these platform environments. The paper workflows use the platform evaluators under `kernelopt/backends/`.

## Local path setup

Treat `05_source_code/` as the project root. From that directory, set source lookup paths on the accelerator host:

```sh
export KERNELBENCH_REPO="$PWD"
export KERNELBENCH_SOURCE_REPO="$PWD"
export PYTHONPATH="$PWD:$PWD/thirdparty/KernelBench/src:${PYTHONPATH:-}"
```

Configure `KERNELBENCH_REMOTE_PYTHON`, the run directory, device visibility, SDK environment scripts and compiler paths for the chosen host. Some launch templates contain case-machine paths; edit deployment configuration to match the installation. The agent executable and authenticated model endpoint used by `kernelopt/agents/agent_driver.py` must be supplied separately; credentials and access to the model labels in the paper are not bundled.

The paper protocol uses standard-normal floating inputs, shared reference/candidate inputs, three correctness seed bases with ten trials each, and a separate timing block at seed 42 with three warmups followed by five forwards. For a new hardware experiment, measure its reference with the same inputs and timing protocol.

Apply the total budget with `scripts/run_with_paper_budget.py --record /path/to/budget.json -- <foreground-workflow-command>` on the accelerator host. The supervisor must wrap the foreground worker; wrapping a command that only queues work does not enforce the worker's budget.

`dependency_links.json` contains the same official links in machine-readable form.  

## Scope of the publication subset

The AKO4ALL `bench/kernelbench/` files are retained upstream CUDA/NCU helpers, not the Ascend or ROCm paper evaluators. Their own trial defaults do not describe the paper case protocols. The paper-platform entry points are `kernelopt/backends/ascend/ascend_bench.py` and `kernelopt/backends/rocm/rocm_bench.py`, both using one five-call timing block after three warmups.

The launchers assemble execution scripts from `kernelopt/`. The package contains all 50 Level-3 workload files and the source required by the Ascend adapter. Licenses accompany the third-party resources.

KDA upstream workflow resources are external. The local `submit_kda_pair.py`, `kda_workflow.py`, `kda_tree.py` and attention reference adapters are included. Set `KDA_SOURCE_DIR` to the fixed upstream checkout and follow `KDA_REFERENCE.md` for checks and submission commands. Host SDKs, isolation and model credentials must be configured separately. Platform knowledge directories are resource indexes, and SDKs and model services require a configured accelerator host.
