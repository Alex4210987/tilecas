# Implementation references

The TileCas agent policy selects a modification, source candidate, and abstraction level. It uses the no-argument diagnosis command when the next step is uncertain. The paper's EvidenceSufficient, ProposeChanges, FeasiblePlans, and SelectPlan describe these agent decisions.

Run the commands below inside the experiment session workspace prepared by the platform launcher. Its `scripts/` directory contains the generated evaluation, diagnosis and export entry points.

| Interface | Purpose |
|---|---|
| `bash scripts/bench.sh iter-N` | Correctness evaluation, timing, and candidate recording |
| `python scripts/diagnose.py` | Candidate-bound timing, source, dataflow, and available hardware evidence |
| `python scripts/export.py --source solution/ModelNew.py --reference reference.py --destination lowered --record lowered/export.json` | High-to-native export with mapping and validation |

The candidate snapshot structure has one derivation parent per node. Cross-branch code reuse is recorded in the iteration history and source records. Profile identifiers, source mappings, and tensor bindings associate observations with a candidate; the agent interprets the observations when choosing an edit.

In the MinGPT iteration-43 diagnosis, the candidate latency is 5.529796 ms. Call 2 maps High `self.qkv` to native kernel_2.cpp with cost 1.845769 ms; call 3 maps `self.attn` to kernel_3.cpp with cost 2.893782 ms. Tensor value_7 connects their producer/consumer bindings. The history then records restoration of High 36, export and validation, attention-source reuse from Low 35, and Low 44 at 4.179405 ms. See `../04_Rollback_traces/MinGPT_trace/run/`.

Fixed uses independent High and Low conversations. Random samples legal actions at eligible checkpoints, lowering the current High candidate or restoring a retained correct High candidate. TileCas maintains the same agent conversation across levels. `ARM_CAPABILITIES.md` gives the paper's full comparison definitions.

The KDA comparison definition remains in the result tables. Its upstream resources are external; `scripts/submit_kda_pair.py` stages the local `kda_workflow.py` and `kda_tree.py` adapters. `KDA_REFERENCE.md` documents the source version and invocation.

Platform policies define the permitted authored kernels and low-level APIs. Precision changes remain subject to the same correctness suite. In the workflow, ROCm uses a full-forward HIP-event interval; Ascend uses the device forward envelope from the earliest attributed task start to the latest completion. Both evaluators use three warmups followed by five timed forwards at timing input seed 42 and report the median. Per-task duration sums are diagnostic only in these evaluators. These two platform intervals have different boundaries and are not claimed to be identical to host request latency. The original case protocols are documented in `../00_paper_protocol/CASE_PROTOCOLS.md`.
