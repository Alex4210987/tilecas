export ROCM_PATH=$HOME/venvs/dsl-native-opt/lib/python3.12/site-packages/_rocm_sdk_devel
export ROCM_HOME="$ROCM_PATH"
export HIP_PATH="$ROCM_PATH"
export PATH="$HOME/venvs/dsl-native-opt/bin:$ROCM_PATH/bin:$HOME/.local/bin:$HOME/.npm-global/bin:$PATH"
export HIP_VISIBLE_DEVICES=0
export PYTORCH_ROCM_ARCH=gfx1201
export TILELANG_HIP_SAVE_TEMP_FILES=0
export LD_LIBRARY_PATH="$HOME/.local/opt/rocm-compat:$ROCM_PATH/lib:${LD_LIBRARY_PATH:-}"

# The devel wheel supplies the unversioned profiler library links.
export ROCPROF_LIST_AVAIL_TOOL_LIBRARY="$ROCM_PATH/lib/rocprofiler-sdk/librocprofv3-list-avail.so"
