# Software details

`software_versions.csv` lists the accelerator toolchains, TileLang, PyTorch, and torch_npu versions. `software_details.txt` explains the selected toolchain paths. `version_records/` contains the version output and deployment excerpts, and `current_package_inspection.json` records the dated package inspection.

The two evaluation platforms are Ascend 910B3 and AMD Radeon AI PRO R9700. The paper uses GPT-6 Astra and DeepSeek-V4.1-Flash with low reasoning effort. Record dates and source paths are retained with the software versions.
