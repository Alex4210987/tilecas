#include "projection.h"
extern "C" int init(){return 0;}
extern "C" int call(float* X,float* W,float* B,float* Y,hipStream_t stream){
 projection<768><<<dim3(12,1024),128,0,stream>>>(X,W,B,Y);
 return hipGetLastError()!=hipSuccess;
}
