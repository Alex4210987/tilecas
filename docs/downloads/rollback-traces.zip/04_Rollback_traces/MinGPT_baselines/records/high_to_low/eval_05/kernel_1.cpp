#include <hip/hip_runtime.h>
using h2=_Float16 __attribute__((ext_vector_type(2)));
using h8=_Float16 __attribute__((ext_vector_type(8)));
using f8=float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ h2 split(float v){_Float16 h=(_Float16)v;return h2{h,(_Float16)(v-(float)h)};}
__device__ __forceinline__ f8 mm(h8 a,h8 ar,h8 b,h8 br,f8 c){
 c=__builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);
 c=__builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,br,c);
 c=__builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(ar,b,c);
 return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(ar,br,c);
}
__global__ __launch_bounds__(128) void attention(const float* Q,float* Y){
 __shared__ h2 q[32][97],kv[32][97],p[32][33];
 __shared__ float s[32][33],mx[32],den[32],scale[32];
 int t=threadIdx.x,l=t%32,w=t/32,qr=(w/2)*16,kn=(w%2)*16;
 int batch=blockIdx.y/8,head=blockIdx.y%8,qbase=blockIdx.x*32;
 const float* base=Q+batch*512*2304+head*96;
 for(int i=t;i<32*96;i+=128){int r=i/96,c=i%96;q[r][c]=split(base[(qbase+r)*2304+c]);}
 if(t<32){mx[t]=-INFINITY;den[t]=0;}
 f8 out[3]={};
 for(int kb=0;kb<=qbase;kb+=32){
  __syncthreads();
  for(int i=t;i<32*96;i+=128){int r=i/96,c=i%96;kv[r][c]=split(base[(kb+r)*2304+768+c]);}
  __syncthreads();
  f8 score={};
  #pragma unroll
  for(int k=0;k<96;k+=16){
   h8 a,ar,b,br;
   #pragma unroll
   for(int e=0;e<8;e++){h2 v=q[qr+l%16][k+l/16*8+e];a[e]=v[0];ar[e]=v[1];v=kv[kn+l%16][k+l/16*8+e];b[e]=v[0];br[e]=v[1];}
   score=mm(a,ar,b,br,score);
  }
  #pragma unroll
  for(int e=0;e<8;e++){int r=qr+l/16*8+e,c=kn+l%16;s[r][c]=(kb+c<=qbase+r)?score[e]*0.10206207261596575f:-INFINITY;}
  __syncthreads();
  #pragma unroll
  for(int i=0;i<4;i++){
   int r=t/16+i*8,c=t%16;
   float u=s[r][c],v=s[r][c+16],m=fmaxf(u,v);
   #pragma unroll
   for(int d=8;d;d/=2)m=fmaxf(m,__shfl_xor(m,d,16));
   m=fmaxf(m,mx[r]);float a=expf(u-m),b=expf(v-m),z=a+b;
   #pragma unroll
   for(int d=8;d;d/=2)z+=__shfl_xor(z,d,16);
   p[r][c]=split(a);p[r][c+16]=split(b);
   if(c==0){float f=expf(mx[r]-m);scale[r]=f;den[r]=den[r]*f+z;mx[r]=m;}
  }
  __syncthreads();
  for(int i=t;i<32*96;i+=128){int r=i/96,c=i%96;kv[r][c]=split(base[(kb+r)*2304+1536+c]);}
  #pragma unroll
  for(int j=0;j<3;j++){
   #pragma unroll
   for(int e=0;e<8;e++)out[j][e]*=scale[qr+l/16*8+e];
  }
  __syncthreads();
  #pragma unroll
  for(int k=0;k<32;k+=16){
   h8 a,ar;
   #pragma unroll
   for(int e=0;e<8;e++){h2 v=p[qr+l%16][k+l/16*8+e];a[e]=v[0];ar[e]=v[1];}
   #pragma unroll
   for(int j=0;j<3;j++){
    h8 b,br;
    #pragma unroll
    for(int e=0;e<8;e++){h2 v=kv[k+l/16*8+e][(w%2)*48+j*16+l%16];b[e]=v[0];br[e]=v[1];}
    out[j]=mm(a,ar,b,br,out[j]);
   }
  }
 }
 #pragma unroll
 for(int j=0;j<3;j++){
  #pragma unroll
  for(int e=0;e<8;e++){
   int r=qr+l/16*8+e,c=(w%2)*48+j*16+l%16;
   Y[(batch*512+qbase+r)*768+head*96+c]=out[j][e]/den[r];
  }
 }
}
extern "C" int init(){return 0;}
extern "C" int call(float* Q,float* Y,hipStream_t stream){attention<<<dim3(16,1024),128,0,stream>>>(Q,Y);return hipGetLastError()!=hipSuccess;}
