#include <hip/hip_runtime.h>
using h2 = _Float16 __attribute__((ext_vector_type(2)));
template<int N> __global__ __launch_bounds__(256) void projection(const float* X,const float* W,const float* B,float* Y){
 __shared__ float a[32][129],b[32][65];
 int t=threadIdx.x,ry=t/16,cx=t%16;
 float acc[8][4]={};
 for(int kb=0;kb<768;kb+=32){
  __syncthreads();
  #pragma unroll
  for(int i=0;i<16;i++){
   int r=t/32+i*8,k=t%32,idx=(blockIdx.y*128+r)*768+kb+k;
   float v;
   if constexpr(N==768){h2 p=((const h2*)X)[idx];v=(float)p[0]+(float)p[1];}else{v=X[idx];}
   a[k][r]=v;
  }
  #pragma unroll
  for(int i=0;i<8;i++){int r=t/32+i*8,k=t%32;b[k][r]=W[(blockIdx.x*64+r)*768+kb+k];}
  __syncthreads();
  #pragma unroll
  for(int k=0;k<32;k++){
   float av[8],bv[4];
   #pragma unroll
   for(int i=0;i<8;i++)av[i]=a[k][ry+i*16];
   #pragma unroll
   for(int j=0;j<4;j++)bv[j]=b[k][cx+j*16];
   #pragma unroll
   for(int i=0;i<8;i++){
    #pragma unroll
    for(int j=0;j<4;j++)acc[i][j]=fmaf(av[i],bv[j],acc[i][j]);
   }
  }
 }
 #pragma unroll
 for(int i=0;i<8;i++){
  #pragma unroll
  for(int j=0;j<4;j++){
   int m=blockIdx.y*128+ry+i*16,n=blockIdx.x*64+cx+j*16;float v=acc[i][j]+B[n];
   if constexpr(N==2304){_Float16 h=(_Float16)v;((h2*)Y)[m*N+n]=h2{h,(_Float16)(v-(float)h)};}else{Y[m*N+n]=v;}
  }
 }
}
