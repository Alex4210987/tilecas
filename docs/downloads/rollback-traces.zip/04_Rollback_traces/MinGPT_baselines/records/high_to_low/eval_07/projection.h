#include <hip/hip_runtime.h>
using h2 = _Float16 __attribute__((ext_vector_type(2)));
using h8 = _Float16 __attribute__((ext_vector_type(8)));
using f8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ f8 mma(h8 a,h8 b,f8 c) {
 return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);
}
template<int N> __global__ __launch_bounds__(128) void projection(const float* X_,const float* W_,const float* B,float* Y) {
 const h2* X=(const h2*)X_;const h2* W=(const h2*)W_;
 __shared__ _Float16 ah[64][40],al[64][40],bh[64][40],bl[64][40];
 int t=threadIdx.x,lane=t%32,wave=t/32;
 int mr=(wave/2)*32,nc=(wave%2)*32;
 f8 hh[2][2]={};
 for(int kb=0;kb<768;kb+=32){
  __syncthreads();
  for(int i=t;i<64*32;i+=128){int r=i/32,k=i%32;h2 a=X[(blockIdx.y*64+r)*768+kb+k],b=W[(blockIdx.x*64+r)*768+kb+k];ah[r][k]=a[0];al[r][k]=a[1];bh[r][k]=b[0];bl[r][k]=b[1];}
  __syncthreads();
  #pragma unroll
  for(int kk=0;kk<32;kk+=16){
   h8 av[2],ar[2],bv[2],br[2];
   #pragma unroll
   for(int i=0;i<2;i++){
    int row=mr+i*16+lane%16,col=nc+i*16+lane%16,k=kk+lane/16*8;
    av[i]=*(h8*)&ah[row][k];ar[i]=*(h8*)&al[row][k];
    bv[i]=*(h8*)&bh[col][k];br[i]=*(h8*)&bl[col][k];
   }
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int j=0;j<2;j++){
     hh[i][j]=mma(av[i],bv[j],hh[i][j]);hh[i][j]=mma(av[i],br[j],hh[i][j]);hh[i][j]=mma(ar[i],bv[j],hh[i][j]);hh[i][j]=mma(ar[i],br[j],hh[i][j]);
    }
   }
  }
 }
 #pragma unroll
 for(int i=0;i<2;i++){
  #pragma unroll
  for(int j=0;j<2;j++){
   int n=blockIdx.x*64+nc+j*16+lane%16;
   #pragma unroll
   for(int e=0;e<8;e++){int m=blockIdx.y*64+mr+i*16+lane/16*8+e;float v=hh[i][j][e]+B[n];if constexpr(N==2304){_Float16 h=(_Float16)v;((h2*)Y)[m*N+n]=h2{h,(_Float16)(v-(float)h)};}else{Y[m*N+n]=v;}}
  }
 }
}
