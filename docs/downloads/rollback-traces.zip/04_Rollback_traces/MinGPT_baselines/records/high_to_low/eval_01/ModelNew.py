from pathlib import Path
import importlib.util

class ModelNew:
    def __init__(self, *args):
        root = Path(__file__).resolve().parent
        spec = importlib.util.spec_from_file_location("candidate_runtime", root / "runtime.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.runtime = module.Runtime(root)

    def to(self, *args, **kwargs):
        return self

    def __call__(self, *args):
        return self.forward(*args)

    def forward(self, *args):
        return self.runtime.forward(*args)
