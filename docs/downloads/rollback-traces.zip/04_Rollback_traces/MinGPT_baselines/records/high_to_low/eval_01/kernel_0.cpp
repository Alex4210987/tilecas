#include <hip/hip_runtime.h>
#include <tl_templates/hip/gemm.h>
#include <tl_templates/hip/copy.h>
#include <tl_templates/hip/reduce.h>
#include <tl_templates/hip/scan.h>
#include <tl_templates/hip/ldsm.h>
#include <tl_templates/hip/threadblock_swizzle.h>
#include <tl_templates/hip/debug.h>

extern "C" __global__ void __launch_bounds__(256) main_kernel(float* __restrict__ B, float* __restrict__ W, float* __restrict__ X, float* __restrict__ Y) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* a = ((void*)((char*)buf_dyn_shmem + 0));
  void* b = ((void*)((char*)buf_dyn_shmem + 8192));
  float c[64];
  #pragma unroll
  for (int i = 0; i < 16; ++i) {
    float broadcast_var = 0.000000e+00f;
    *(float4*)(c + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  for (int ko = 0; ko < 48; ++ko) {
    __syncthreads();
    #pragma unroll
    for (int i_1 = 0; i_1 < 8; ++i_1) {
      ((float*)a)[((((((int)threadIdx.x) & 15) * 128) + (i_1 * 16)) + (((int)threadIdx.x) >> 4))] = X[(((((((int)blockIdx.y) * 98304) + (i_1 * 12288)) + ((((int)threadIdx.x) >> 4) * 768)) + (ko * 16)) + (((int)threadIdx.x) & 15))];
    }
    #pragma unroll
    for (int i_2 = 0; i_2 < 8; ++i_2) {
      ((float*)b)[((((((int)threadIdx.x) & 15) * 128) + (i_2 * 16)) + (((int)threadIdx.x) >> 4))] = W[(((((((int)blockIdx.x) * 98304) + (i_2 * 12288)) + ((((int)threadIdx.x) >> 4) * 768)) + (ko * 16)) + (((int)threadIdx.x) & 15))];
    }
    __syncthreads();
    #pragma unroll
    for (int k = 0; k < 16; ++k) {
      #pragma unroll
      for (int i_3 = 0; i_3 < 64; ++i_3) {
        c[i_3] = (c[i_3] + (((float*)a)[(((k * 128) + ((i_3 >> 3) * 16)) + (((int)threadIdx.x) >> 4))] * ((float*)b)[(((k * 128) + ((i_3 & 7) * 16)) + (((int)threadIdx.x) & 15))]));
      }
    }
  }
  #pragma unroll
  for (int i_4 = 0; i_4 < 64; ++i_4) {
    Y[((((((((int)blockIdx.y) * 294912) + ((i_4 >> 3) * 36864)) + ((((int)threadIdx.x) >> 4) * 2304)) + (((int)blockIdx.x) * 128)) + ((i_4 & 7) * 16)) + (((int)threadIdx.x) & 15))] = (c[i_4] + B[(((((int)blockIdx.x) * 128) + ((i_4 & 7) * 16)) + (((int)threadIdx.x) & 15))]);
  }
}


#ifdef _WIN32
#define TL_EXPORT __declspec(dllexport)
#else
#define TL_EXPORT
#endif

#define ERROR_BUF_SIZE 1024
static char error_buf[ERROR_BUF_SIZE];

extern "C" TL_EXPORT const char* get_last_error() {
    return error_buf;
}

extern "C" TL_EXPORT int init() {
    error_buf[0] = '\0';
    
    int device_main_kernel = 0;
    hipError_t dev_res_main_kernel = hipGetDevice(&device_main_kernel);
    if (dev_res_main_kernel != hipSuccess) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to get HIP device for main_kernel: %s", hipGetErrorString(dev_res_main_kernel));
        return -1;
    }
    int max_smem_main_kernel = 0;
    hipError_t attr_res_main_kernel = hipDeviceGetAttribute(&max_smem_main_kernel, hipDeviceAttributeMaxSharedMemoryPerBlock, device_main_kernel);
    if (attr_res_main_kernel != hipSuccess || max_smem_main_kernel <= 0) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to query HIP max shared memory for main_kernel: %s", hipGetErrorString(attr_res_main_kernel));
        return -1;
    }
    if (16384 > max_smem_main_kernel) {
        snprintf(
            error_buf,
            ERROR_BUF_SIZE,
            "Requested dynamic shared memory %d exceeds device limit %d for main_kernel",
            16384,
            max_smem_main_kernel
        );
        return -1;
    }
    return 0;

    return 0;
}

extern "C" TL_EXPORT int call(float* __restrict__ X, float* __restrict__ W, float* __restrict__ B, float* __restrict__ Y, hipStream_t stream=hipStreamDefault) {
	main_kernel<<<dim3(18, 512, 1), dim3(256, 1, 1), 16384, stream>>>(B, W, X, Y);
	TILELANG_CHECK_LAST_ERROR("main_kernel");

	return 0;
}
