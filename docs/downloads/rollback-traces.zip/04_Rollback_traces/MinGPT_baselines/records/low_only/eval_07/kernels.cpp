#include <hip/hip_runtime.h>
#include <math.h>
using H8 = _Float16 __attribute__((ext_vector_type(8)));
using F8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ F8 mma(H8 a,H8 b,F8 c){return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);}
__global__ void linear(const float* A,const float* B,const float* bias,float* C,int N){
 __shared__ _Float16 ah[128][40],al[128][40],bh[64][40],bl[64][40];
 int t=threadIdx.x,l=t%32,w=t/32,wm=w/2*32,wn=w%2*32;
 int m0=blockIdx.y*128,n0=blockIdx.x*64;
 int K=768;
 F8 acc[2][2]={},err[2][2]={};
 for(int kk=0;kk<K;kk+=32){
  for(int idx=t;idx<4096;idx+=256){int r=idx/32,k=idx%32;float a=A[(m0+r)*768+kk+k];
   _Float16 hi=(_Float16)a;ah[r][k]=hi;al[r][k]=(_Float16)((a-(float)hi)*4096.f);
  }
  for(int idx=t;idx<2048;idx+=256){int r=idx/32,k=idx%32;float b=B[(n0+r)*768+kk+k];
   _Float16 hi=(_Float16)b;bh[r][k]=hi;bl[r][k]=(_Float16)((b-(float)hi)*4096.f);
  }__syncthreads();
  #pragma unroll
  for(int k=0;k<32;k+=16){
   H8 a[2],b[2],ae[2],be[2];
   #pragma unroll
   for(int i=0;i<2;i++){
    a[i]=*(H8*)&ah[wm+i*16+l%16][k+l/16*8];ae[i]=*(H8*)&al[wm+i*16+l%16][k+l/16*8];
    b[i]=*(H8*)&bh[wn+i*16+l%16][k+l/16*8];be[i]=*(H8*)&bl[wn+i*16+l%16][k+l/16*8];
   }
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int j=0;j<2;j++){acc[i][j]=mma(a[i],b[j],acc[i][j]);err[i][j]=mma(ae[i],b[j],err[i][j]);err[i][j]=mma(a[i],be[j],err[i][j]);}
   }
  }__syncthreads();
 }
 for(int i=0;i<2;i++)for(int j=0;j<2;j++)for(int e=0;e<8;e++){
  int m=m0+wm+i*16+l/16*8+e,n=n0+wn+j*16+l%16;
  float v=acc[i][j][e]+err[i][j][e]*(1.f/4096.f);
  C[m*N+n]=v+bias[n];
 }
}
// A query tile stays in one block through scores, stable softmax and values.
__global__ void attention(const float* qkv,float* y){
 __shared__ float score[16][512];
 _Float16* packed=(_Float16*)score;
 int t=threadIdx.x,l=t%32,w=t/32,q0=blockIdx.x*16,z=blockIdx.y,b=z/8,h=z%8;
 for(int j=0;j<8;j++){
  int n0=w*128+j*16;
  F8 a0={},ae0={};
  if(n0<=q0){
   for(int k=0;k<96;k+=16){H8 a,ae,bv,be;
    #pragma unroll
    for(int e=0;e<8;e++){
     float av=qkv[(b*512+q0+l%16)*2304+h*96+k+l/16*8+e];
     float bb=qkv[(b*512+n0+l%16)*2304+768+h*96+k+l/16*8+e];
     a[e]=(_Float16)av;ae[e]=(_Float16)((av-(float)a[e])*4096.f);
     bv[e]=(_Float16)bb;be[e]=(_Float16)((bb-(float)bv[e])*4096.f);
    }
    a0=mma(a,bv,a0);ae0=mma(ae,bv,ae0);ae0=mma(a,be,ae0);
   }
  }
  #pragma unroll
  for(int e=0;e<8;e++){int r=l/16*8+e,n=n0+l%16;score[r][n]=n<=q0+r?(a0[e]+ae0[e]/4096.f)*0.10206207261596575f:-INFINITY;}
 }
 __syncthreads();
 for(int r=w;r<16;r+=4){
  float v[16],mx=-INFINITY;
  #pragma unroll
  for(int i=0;i<16;i++){v[i]=score[r][i*32+l];mx=fmaxf(mx,v[i]);}
  for(int d=16;d;d/=2)mx=fmaxf(mx,__shfl_xor(mx,d));
  float sum=0;
  #pragma unroll
  for(int i=0;i<16;i++){v[i]=expf(v[i]-mx);sum+=v[i];}
  for(int d=16;d;d/=2)sum+=__shfl_xor(sum,d);
  #pragma unroll
  for(int i=0;i<16;i++){float p=v[i]/sum;_Float16 hi=(_Float16)p;int off=(r*512+i*32+l)*2;packed[off]=hi;packed[off+1]=(_Float16)((p-(float)hi)*4096.f);}
 }
 __syncthreads();
 if(w<3){
  F8 c[2]={},ce[2]={};
  for(int k=0;k<q0+16;k+=16){
   H8 a,ae;
   #pragma unroll
   for(int e=0;e<8;e++){int off=((l%16)*512+k+l/16*8+e)*2;a[e]=packed[off];ae[e]=packed[off+1];}
   #pragma unroll
   for(int j=0;j<2;j++){
    H8 bv,be;
    #pragma unroll
    for(int e=0;e<8;e++){float v=qkv[(b*512+k+l/16*8+e)*2304+1536+h*96+w*32+j*16+l%16];bv[e]=(_Float16)v;be[e]=(_Float16)((v-(float)bv[e])*4096.f);}
    c[j]=mma(a,bv,c[j]);ce[j]=mma(ae,bv,ce[j]);ce[j]=mma(a,be,ce[j]);
   }
  }
  for(int j=0;j<2;j++)for(int e=0;e<8;e++)y[(b*512+q0+l/16*8+e)*768+h*96+w*32+j*16+l%16]=c[j][e]+ce[j][e]/4096.f;
 }
}
extern "C" int init(){return (int)hipInit(0);}
extern "C" int call(float*x,float*w,float*b,float*p,float*pb,float*qkv,float*y,float*out,hipStream_t stream){
 linear<<<dim3(36,512),256,0,stream>>>(x,w,b,qkv,2304);
 attention<<<dim3(32,1024),128,0,stream>>>(qkv,y);
 linear<<<dim3(12,512),256,0,stream>>>(y,p,pb,out,768);
 return (int)hipGetLastError();
}
