#include <hip/hip_runtime.h>
#include <math.h>
template<int MODE> __global__ void gemm(const float* A,const float* B,const float* bias,float* C,int M,int N,int K){
 __shared__ float sa[16][64],sb[16][64];
 int t=threadIdx.x, rm=t/16*4, cn=t%16*4;
 int m0=blockIdx.y*64,n0=blockIdx.x*64,z=blockIdx.z;
 int batch=z/8,head=z%8;
 float acc[4][4]={};
 for(int kk=0;kk<K;kk+=16){
  for(int i=t;i<1024;i+=256){int k=i/64,r=i%64,m=m0+r,n=n0+r;float av=0,bv=0;
   if(m<M){if constexpr(MODE==0) av=A[m*K+kk+k];
    if constexpr(MODE==1) av=A[(batch*512+m)*2304+head*96+kk+k];
    if constexpr(MODE==2) av=A[(z*512+m)*512+kk+k];}
   if(n<N){if constexpr(MODE==0) bv=B[n*K+kk+k];
    if constexpr(MODE==1) bv=B[(batch*512+n)*2304+768+head*96+kk+k];
    if constexpr(MODE==2) bv=B[(batch*512+kk+k)*2304+1536+head*96+n];}
   sa[k][r]=av;sb[k][r]=bv;
  }__syncthreads();
  #pragma unroll
  for(int k=0;k<16;k++){
   #pragma unroll
   for(int i=0;i<4;i++){
    #pragma unroll
    for(int j=0;j<4;j++)acc[i][j]=fmaf(sa[k][rm+i],sb[k][cn+j],acc[i][j]);
   }
  }__syncthreads();
 }
 for(int i=0;i<4;i++)for(int j=0;j<4;j++){int m=m0+rm+i,n=n0+cn+j;if(m<M&&n<N){float v=acc[i][j];
  if constexpr(MODE==0) C[m*N+n]=v+bias[n];
  if constexpr(MODE==1) C[(z*512+m)*512+n]=(n<=m)?v*0.10206207261596575f:-INFINITY;
  if constexpr(MODE==2) C[(batch*512+m)*768+head*96+n]=v;
 }}
}
__global__ void softmax(float* a){
 int r=blockIdx.x,t=threadIdx.x;float x=a[r*512+t],y=a[r*512+t+256];
 __shared__ float s[256];s[t]=fmaxf(x,y);__syncthreads();
 for(int d=128;d;d/=2){if(t<d)s[t]=fmaxf(s[t],s[t+d]);__syncthreads();}
 float mx=s[0];__syncthreads();x=expf(x-mx);y=expf(y-mx);s[t]=x+y;__syncthreads();
 for(int d=128;d;d/=2){if(t<d)s[t]+=s[t+d];__syncthreads();}
 a[r*512+t]=x/s[0];a[r*512+t+256]=y/s[0];
}
using H8 = _Float16 __attribute__((ext_vector_type(8)));
using F8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ F8 mma(H8 a,H8 b,F8 c){return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);}
template<int MODE> __global__ void linear(const float* A,const float* B,const float* bias,float* C,int N){
 __shared__ _Float16 ah[64][40],al[64][40],bh[64][40],bl[64][40];
 int t=threadIdx.x,l=t%32,w=t/32,wm=w/2*32,wn=w%2*32;
 int m0=blockIdx.y*64,n0=blockIdx.x*64,z=blockIdx.z,batch=z/8,head=z%8;
 if constexpr(MODE==1){if(n0>m0){for(int i=t;i<4096;i+=128)C[(z*512+m0+i/64)*512+n0+i%64]=-INFINITY;return;}}
 int K=MODE==0?768:(MODE==1?96:m0+64);
 F8 acc[2][2]={},err[2][2]={};
 for(int kk=0;kk<K;kk+=32){
  for(int z=t;z<2048;z+=128){int r=z/32,k=z%32;float a,b;
   if constexpr(MODE==0){a=A[(m0+r)*768+kk+k];b=B[(n0+r)*768+kk+k];}
   if constexpr(MODE==1){a=A[(batch*512+m0+r)*2304+head*96+kk+k];b=B[(batch*512+n0+r)*2304+768+head*96+kk+k];}
   if constexpr(MODE==2){a=A[(z*512+m0+r)*512+kk+k];b=n0+r<96?B[(batch*512+kk+k)*2304+1536+head*96+n0+r]:0;}

   _Float16 h=(_Float16)a,g=(_Float16)b;ah[r][k]=h;al[r][k]=(_Float16)((a-(float)h)*4096.f);bh[r][k]=g;bl[r][k]=(_Float16)((b-(float)g)*4096.f);
  }__syncthreads();
  #pragma unroll
  for(int k=0;k<32;k+=16){
   H8 a[2],b[2],ae[2],be[2];
   #pragma unroll
   for(int i=0;i<2;i++){
    a[i]=*(H8*)&ah[wm+i*16+l%16][k+l/16*8];ae[i]=*(H8*)&al[wm+i*16+l%16][k+l/16*8];
    b[i]=*(H8*)&bh[wn+i*16+l%16][k+l/16*8];be[i]=*(H8*)&bl[wn+i*16+l%16][k+l/16*8];
   }
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int j=0;j<2;j++){acc[i][j]=mma(a[i],b[j],acc[i][j]);err[i][j]=mma(ae[i],b[j],err[i][j]);err[i][j]=mma(a[i],be[j],err[i][j]);}
   }
  }__syncthreads();
 }
 for(int i=0;i<2;i++)for(int j=0;j<2;j++)for(int e=0;e<8;e++){
  int m=m0+wm+i*16+l/16*8+e,n=n0+wn+j*16+l%16;
  float v=acc[i][j][e]+err[i][j][e]*(1.f/4096.f);
  if constexpr(MODE==0) C[m*N+n]=v+bias[n];
  if constexpr(MODE==1) C[(z*512+m)*512+n]=n<=m?v*0.10206207261596575f:-INFINITY;
  if constexpr(MODE==2) if(n<96)C[(batch*512+m)*768+head*96+n]=v;
 }
}
extern "C" int init(){return (int)hipInit(0);}
extern "C" int call(float*x,float*w,float*b,float*p,float*pb,float*qkv,float*att,float*y,float*out,hipStream_t stream){
 linear<0><<<dim3(36,1024),128,0,stream>>>(x,w,b,qkv,2304);
 linear<1><<<dim3(8,8,1024),128,0,stream>>>(qkv,qkv,nullptr,att,512);
 softmax<<<524288,256,0,stream>>>(att);
 linear<2><<<dim3(2,8,1024),128,0,stream>>>(att,qkv,nullptr,y,96);
 linear<0><<<dim3(12,1024),128,0,stream>>>(y,p,pb,out,768);
 return (int)hipGetLastError();
}
