#include <hip/hip_runtime.h>
#include <math.h>
template<int MODE> __global__ void gemm(const float* A,const float* B,const float* bias,float* C,int M,int N,int K){
 __shared__ float sa[16][64],sb[16][64];
 int t=threadIdx.x, rm=t/16*4, cn=t%16*4;
 int m0=blockIdx.y*64,n0=blockIdx.x*64,z=blockIdx.z;
 int batch=z/8,head=z%8;
 float acc[4][4]={};
 for(int kk=0;kk<K;kk+=16){
  for(int i=t;i<1024;i+=256){int k=i/64,r=i%64,m=m0+r,n=n0+r;float av=0,bv=0;
   if(m<M){if constexpr(MODE==0) av=A[m*K+kk+k];
    if constexpr(MODE==1) av=A[(batch*512+m)*2304+head*96+kk+k];
    if constexpr(MODE==2) av=A[(z*512+m)*512+kk+k];}
   if(n<N){if constexpr(MODE==0) bv=B[n*K+kk+k];
    if constexpr(MODE==1) bv=B[(batch*512+n)*2304+768+head*96+kk+k];
    if constexpr(MODE==2) bv=B[(batch*512+kk+k)*2304+1536+head*96+n];}
   sa[k][r]=av;sb[k][r]=bv;
  }__syncthreads();
  #pragma unroll
  for(int k=0;k<16;k++){
   #pragma unroll
   for(int i=0;i<4;i++){
    #pragma unroll
    for(int j=0;j<4;j++)acc[i][j]=fmaf(sa[k][rm+i],sb[k][cn+j],acc[i][j]);
   }
  }__syncthreads();
 }
 for(int i=0;i<4;i++)for(int j=0;j<4;j++){int m=m0+rm+i,n=n0+cn+j;if(m<M&&n<N){float v=acc[i][j];
  if constexpr(MODE==0) C[m*N+n]=v+bias[n];
  if constexpr(MODE==1) C[(z*512+m)*512+n]=(n<=m)?v*0.10206207261596575f:-INFINITY;
  if constexpr(MODE==2) C[(batch*512+m)*768+head*96+n]=v;
 }}
}
__global__ void softmax(float* a){
 int r=blockIdx.x,t=threadIdx.x;float x=a[r*512+t],y=a[r*512+t+256];
 __shared__ float s[256];s[t]=fmaxf(x,y);__syncthreads();
 for(int d=128;d;d/=2){if(t<d)s[t]=fmaxf(s[t],s[t+d]);__syncthreads();}
 float mx=s[0];__syncthreads();x=expf(x-mx);y=expf(y-mx);s[t]=x+y;__syncthreads();
 for(int d=128;d;d/=2){if(t<d)s[t]+=s[t+d];__syncthreads();}
 a[r*512+t]=x/s[0];a[r*512+t+256]=y/s[0];
}
extern "C" int init(){return (int)hipInit(0);}
extern "C" int call(float*x,float*w,float*b,float*p,float*pb,float*qkv,float*att,float*y,float*out,hipStream_t stream){
 gemm<0><<<dim3(36,1024),256,0,stream>>>(x,w,b,qkv,65536,2304,768);
 gemm<1><<<dim3(8,8,1024),256,0,stream>>>(qkv,qkv,nullptr,att,512,512,96);
 softmax<<<524288,256,0,stream>>>(att);
 gemm<2><<<dim3(2,8,1024),256,0,stream>>>(att,qkv,nullptr,y,512,96,512);
 gemm<0><<<dim3(12,1024),256,0,stream>>>(y,p,pb,out,65536,768,768);
 return (int)hipGetLastError();
}
