import torch
import tilelang
import tilelang.language as T

@tilelang.jit(target="hip", execution_backend="cython")
def projection(N: int, BM: int = 64, BN: int = 64, BK: int = 16):
    @T.prim_func
    def main(X: T.Tensor((65536,768),'float32'), W: T.Tensor((N,768),'float32'), B: T.Tensor((N,),'float32'), Y: T.Tensor((65536,N),'float32')):
        with T.Kernel(T.ceildiv(N,BN), T.ceildiv(65536,BM), threads=128) as (bx,by):
            a=T.alloc_shared((BM,BK),'float32')
            b=T.alloc_shared((BK,BN),'float32')
            c=T.alloc_fragment((BM,BN),'float32')
            T.annotate_layout({c: tilelang.Fragment((BM,BN),forward_thread_fn=lambda i,j: (i%8)*16+j%16)})
            T.clear(c)
            for ko in T.serial(768//BK):
                T.copy(X[by*BM,ko*BK],a)
                for j,k in T.Parallel(BN,BK):
                    b[k,j]=W[bx*BN+j,ko*BK+k]
                for k in T.unroll(BK):
                    for i,j in T.Parallel(BM,BN):
                        c[i,j]+=a[i,k]*b[k,j]
            for i,j in T.Parallel(BM,BN):
                Y[by*BM+i,bx*BN+j]=c[i,j]+B[bx*BN+j]
    return main

@tilelang.jit(target="hip", execution_backend="cython")
def scores(BM: int=32, BN: int=32, BK: int=16):
    @T.prim_func
    def main(Q: T.Tensor((128,512,2304),'float32'), S: T.Tensor((128,8,512,512),'float32')):
        with T.Kernel(512//BN,512//BM,1024,threads=128) as (bx,by,bh):
            a=T.alloc_shared((BM,BK),'float32')
            b=T.alloc_shared((BK,BN),'float32')
            c=T.alloc_fragment((BM,BN),'float32')
            T.annotate_layout({c: tilelang.Fragment((BM,BN),forward_thread_fn=lambda i,j: (i%8)*16+j%16)})
            T.clear(c)
            if bx*BN<=by*BM+BM-1:
                for ko in T.serial(96//BK):
                    for i,k in T.Parallel(BM,BK):
                        a[i,k]=Q[bh//8,by*BM+i,bh%8*96+ko*BK+k]
                    for j,k in T.Parallel(BN,BK):
                        b[k,j]=Q[bh//8,bx*BN+j,768+bh%8*96+ko*BK+k]
                    for k in T.unroll(BK):
                        for i,j in T.Parallel(BM,BN):
                            c[i,j]+=a[i,k]*b[k,j]
            for i,j in T.Parallel(BM,BN):
                S[bh//8,bh%8,by*BM+i,bx*BN+j]=T.if_then_else(bx*BN+j<=by*BM+i,c[i,j]*0.10206207261596575,-T.infinity('float32'))
    return main

@tilelang.jit(target="hip", execution_backend="cython")
def normalize():
    @T.prim_func
    def main(S: T.Tensor((524288,512),'float32'), P: T.Tensor((524288,512),'float32')):
        with T.Kernel(524288,threads=128) as row:
            v=T.alloc_fragment((512,),'float32')
            m=T.alloc_fragment((1,),'float32')
            d=T.alloc_fragment((1,),'float32')
            T.copy(S[row,0],v)
            T.reduce_max(v,m,dim=0)
            for j in T.Parallel(512):
                v[j]=T.exp(v[j]-m[0])
            T.reduce_sum(v,d,dim=0)
            for j in T.Parallel(512):
                P[row,j]=v[j]/d[0]
    return main

@tilelang.jit(target="hip", execution_backend="cython")
def values(BM: int=32, BN: int=32, BK: int=16):
    @T.prim_func
    def main(P: T.Tensor((128,8,512,512),'float32'), Q: T.Tensor((128,512,2304),'float32'), Y: T.Tensor((128,512,768),'float32')):
        with T.Kernel(96//BN,512//BM,1024,threads=128) as (bx,by,bh):
            a=T.alloc_shared((BM,BK),'float32')
            b=T.alloc_shared((BK,BN),'float32')
            c=T.alloc_fragment((BM,BN),'float32')
            T.annotate_layout({c: tilelang.Fragment((BM,BN),forward_thread_fn=lambda i,j: (i%8)*16+j%16)})
            T.clear(c)
            for ko in T.serial(T.ceildiv((by+1)*BM,BK)):
                for i,k in T.Parallel(BM,BK):
                    a[i,k]=P[bh//8,bh%8,by*BM+i,ko*BK+k]
                for k,j in T.Parallel(BK,BN):
                    b[k,j]=Q[bh//8,ko*BK+k,1536+bh%8*96+bx*BN+j]
                for k in T.unroll(BK):
                    for i,j in T.Parallel(BM,BN):
                        c[i,j]+=a[i,k]*b[k,j]
            for i,j in T.Parallel(BM,BN):
                Y[bh//8,by*BM+i,bh%8*96+bx*BN+j]=c[i,j]
    return main

class ModelNew:
    def __init__(self,n_embd,n_head,attn_pdrop,resid_pdrop,max_seqlen):
        self.qkv=projection(2304)
        self.proj=projection(768)
        self.score=scores()
        self.norm=normalize()
        self.value=values()
    def to(self,*args,**kwargs): return self
    def __call__(self,*args): return self.forward(*args)
    def forward(self,x,qkv_weight,qkv_bias,projection_weight,projection_bias):
        q=torch.empty((128,512,2304),device=x.device,dtype=x.dtype)
        s=torch.empty((128,8,512,512),device=x.device,dtype=x.dtype)
        p=torch.empty_like(s)
        y=torch.empty_like(x)
        out=torch.empty_like(x)
        self.qkv(x.view(65536,768),qkv_weight,qkv_bias,q.view(65536,2304))
        self.score(q,s)
        self.norm(s.view(524288,512),p.view(524288,512))
        self.value(p,q,y)
        self.proj(y.view(65536,768),projection_weight,projection_bias,out.view(65536,768))
        return out
