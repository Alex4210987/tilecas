# High-to-Low — paper evaluation table

Values use the paper reporting convention. Each evaluation links to its corresponding record and candidate directory.

| Evaluation | Elapsed min | Outcome | Candidate ms | Speedup | Best-so-far |
|---|---:|---|---:|---:|---:|
| [baseline](records/high_to_low/eval_01/output.txt) | 24.984550 | passed | 34.037487 | 1.262391x | 1.264053x |
| [iter-1](records/high_to_low/eval_02/output.txt) | 26.952268 | passed | 44.443237 | 0.966820x | 1.264053x |
| [iter-2](records/high_to_low/eval_03/output.txt) | 28.896039 | passed | 55.280201 | 0.777288x | 1.264053x |
| [iter-3](records/high_to_low/eval_04/output.txt) | 30.456453 | passed | 29.298832 | 1.466565x | 1.466565x |
| [iter-4](records/high_to_low/eval_05/output.txt) | 32.775759 | passed | 28.994980 | 1.481933x | 1.481933x |
| [iter-5](records/high_to_low/eval_06/output.txt) | 34.182655 | passed | 28.269505 | 1.519964x | 1.519964x |
| [iter-6](records/high_to_low/eval_07/output.txt) | 35.610994 | passed | 30.991692 | 1.386456x | 1.519964x |
| [iter-7](records/high_to_low/eval_08/output.txt) | 37.019012 | passed | 30.370373 | 1.414821x | 1.519964x |
| [iter-8](records/high_to_low/eval_09/output.txt) | 38.145850 | passed | 27.587326 | 1.557550x | 1.557550x |
| [iter-9](records/high_to_low/eval_10/output.txt) | 40.123820 | passed | 21.748953 | 1.975664x | 1.975664x |
| [iter-10](records/high_to_low/eval_11/output.txt) | 41.308541 | passed | 20.533800 | 2.092581x | 2.092581x |
| [iter-11](records/high_to_low/eval_12/output.txt) | 42.308467 | passed | 19.316040 | 2.224505x | 2.224505x |
| [iter-12](records/high_to_low/eval_13/output.txt) | 43.486963 | passed | 19.291344 | 2.227353x | 2.227353x |
| [iter-13](records/high_to_low/eval_14/output.txt) | 44.385736 | passed | 20.710352 | 2.074742x | 2.227353x |
| [iter-14](records/high_to_low/eval_15/output.txt) | 45.587655 | passed | 18.693844 | 2.298544x | 2.298544x |
| [final](records/high_to_low/eval_16/output.txt) | 46.642607 | passed | 18.659235 | 2.302808x | 2.302808x |
