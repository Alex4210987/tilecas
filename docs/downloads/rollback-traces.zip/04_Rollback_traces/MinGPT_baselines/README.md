# MinGPT comparison data — Figures 1 and 5

The directory contains the paper's High-only, Low-only, and High-to-Low comparison data, with candidate source files and evaluation records. Numerical tables in this directory use the paper's reporting values and elapsed-time coordinates.

| View | Run/session | Evaluations |
|---|---|---:|
| High-only | `kb-fixed-rocm-mingpt-astra-low-20261002-162303`, session 1 | 12 |
| Low-only | `kb-native-only-rocm-mingpt-astra-low-20261002-172255`, session 2 | 16 |
| High-to-Low | The same Fixed run, session 2 following its High prefix | 16 additional |

High-only is the High stage of Fixed. The High-to-Low view uses that same High prefix followed by the Low-stage continuation.

The High stage is a complete AKO invocation that terminated autonomously under its stopping rules. Its approximately 14.72-minute duration is the observed completion time. [High-only search and autonomous termination](HIGH_ONLY_NOTE.md) explains its operational equivalence to standalone High-only, the shared trajectory, and the interpretation of the motivation figures.

| File or directory | Contents |
|---|---|
| `high_only.md`, `low_only.md`, `high_to_low.md` | Evaluation tables with links to records |
| `iteration_results.csv` | 44 evaluations, their status, source-run identifiers, and paper values |
| `records/` | Candidate source and corresponding paper-value records |
| `timing_samples.csv` | 420 timing values associated with the 42 successful evaluations |
| `best_so_far.csv` | Paper elapsed-time coordinates and best-so-far speedups; join the High prefix to the Low continuation for High-to-Low |
| `paper_curves.csv` | Curve coordinates from Figure 1(b) and Figure 5; Figure 1(a) uses the High-only and Low-only series |
| `references/` | Reference workload source |
| `run_manifest.json` | Run/session mapping, figure references, protocol, and record counts |

The reporting reference for Figures 1 and 5 is 42.968631744384766 ms. Figure 4 uses the TileCas case reference of 44.953800201416016 ms. Each figure retains its own reference.

The failed High attempt and the unaccepted Low-only iter-2 retain their recorded status and empty timing blocks. The paper protocol is described in `../../00_paper_protocol/CASE_PROTOCOLS.md`.
