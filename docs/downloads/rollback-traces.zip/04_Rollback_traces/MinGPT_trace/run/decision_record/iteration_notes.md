


# TileCas iterations

Hardware: gfx1201 Radeon AI PRO R9700; actual device reports 32 multiprocessors, 32-lane warps, 65536 bytes shared memory/block, 1024 threads/block, 8 MiB L2. Window 09:54–11:54 UTC.

## iter-1 — High root
Empty parent. Tiled 64x64 projections (FP16 operands, FP32 accumulation), explicit QK, stable softmax, PV and output projection. High conveniently expresses the full dataflow. FP16 intermediate precision is validated, not assumed.
Complete suite PASS, median 24.242527 ms, samples 24.190–24.357 ms, fixed-reference speedup 1.8543x. Promoted as first correct baseline.
Next: fuse attention with online softmax to remove score/probability traffic and exploit causality; keep projections unchanged for attribution.

## iter-2 — High structural child of iter-1 (078791f)
Fused 32-query/64-key online stable softmax attention, FP32 running numerator/denominator, causal block bound. Projection kernels unchanged. Complete suite PASS; 21.111492 ms (21.045–21.161), 2.1294x. Promoted. Removes global S/P tensors, but only 3.13 ms total saved. Next cost split is uncertain between strided attention and projection conversion/reloads; diagnose unchanged candidate.

## iter-3 — High structural child of iter-2 (861d582)
Diagnosis: QKV 13.12 ms, output projection 4.80 ms, attention 3.18 ms. Native projection has repeated FP32 loads/conversions per tile, two barriers per 32-wide reduction chunk; counter symbols ambiguous, no utilization inference. Convert activation and both weights once per forward; retain half attention output (same rounding previously performed by projection loads). No cached parameter data. Remove unused explicit attention definitions.
Complete suite PASS; 13.495666 ms (13.427–13.500), 3.3310x. Promoted. Next increase projection reuse and reduction chunk to reduce traffic/barriers.

## iter-4 — High tuning child of iter-3 (a147944)
Projection tile 128x128x64, 256 threads (32 KiB LDS), versus 64x64x32/128. Complete suite PASS; 9.107313 ms (9.054–9.147), 4.9360x. Promoted. Coupled geometry/thread ownership increases reuse and halves reduction barriers. Next test grouped grid ordering: current x-major M traversal streams the entire activation once per output tile; nearby output tiles could reuse activation from L2.

## iter-5 — High tuning child of iter-4 (532f4ad)
Grouped traversal attempt. Compile FAIL: API accepts `column`, not `col`; no latency. Rejected implementation; fix concrete argument error next.

## iter-6 — High repair child of iter-5 (a0ad233)
Correct `column` swizzle, group eight M tiles. Complete suite PASS; 6.419225 ms (6.412–6.474), 7.0030x. Promoted. Strong improvement supports activation reuse hypothesis, despite reference timing drift. Next increase attention query tile 32→64 to reuse K/V and reduce block count.

## iter-7 — High tuning child of iter-6 (8a2c7db)
Attention BM64/BN64/128 threads, 44 KiB nominal LDS versus 32 KiB BM32. Complete suite PASS; 7.377487 ms (7.316–7.465). Retained for exploration, not promoted. Larger tile alone regresses; test coupled 256-thread ownership before rejecting reuse mechanism.

## iter-8 — High tuning child of iter-7 (26e520e)
BM64/BN64 with 256 attention threads. Complete suite PASS; 5.681181 ms (5.593–5.817), 7.9128x. Promoted over iter-6. Thread ownership materially changes outcome, supporting coupled geometry exploration. Correction: iter-7 nominal array sum is 44 KiB; BM32 sum is 34 KiB (not 32). Actual allocation can differ due to lifetimes/layouts; no occupancy claim from nominal totals.
Next BM128/BN64/256 uses nominal 64 KiB, within queried limit; measure feasibility and speed.

## iter-9 — High tuning child of iter-8 (571ca47)
BM128/BN64/256. Compile/init FAIL: actual allocation 67584 bytes includes 2048-byte reduction workspace, exceeding 65536. No latency. Next move V load after score/softmax so K and V lifetimes can share LDS; this is a concrete local buffer lifetime repair, not rejection of larger tile.

## iter-10 — High repair child of iter-9 (d9e6ed7)
Delayed V load after score consumption, but compiler still allocates separate K/V buffers, same 67584-byte init failure. No latency. A specific remaining repair is explicit K/V buffer reuse (identical 64x96 shape), letting synchronization enforce overwrite after QK consumption.

## iter-11 — High repair child of iter-10 (18c82a9)
Explicit shared K/V buffer reuse makes BM128/BN64/256 feasible. Complete suite PASS; 5.788879 ms (5.735–5.844). Retain alternative, not promoted over iter-8; spread overlaps and median is worse. Next reduce key tile to 32 and query tile to 64, retaining shared buffer, to test lower LDS with 128 threads.

## iter-12 — High tuning child of iter-11 (46e217c)
BM64/BN32/128 attention with shared K/V. Complete suite PASS; 6.390876 ms (6.367–6.410). Rejected for speed. More loop/reduction overhead outweighs this tested resource balance. Restore iter-8 and diagnose: projections and attention have both changed materially since old costs, so next dominant opportunity is uncertain.

### Restore/diagnose iter-8
Restored exact High iter-8 source. Refreshed matched costs: attention 2.786 ms, QKV 1.759 ms, projection 0.624 ms, x conversion 0.543 ms. Native PV uses scalar strided LDS loads (8 scalar half elements per operand) while QK uses uint4 vector LDS loads. Hypothesis: store V transposed in shared memory to permit vector PV operand reads. Stay High because shared layout change is directly expressible; no Native control required yet.

## iter-13 — High layout child of restored iter-8 (ceba0f4)
Transpose V in LDS; PV now transposed-B WMMA. Complete suite PASS; 5.839069 ms (5.792–5.901). Not promoted; no demonstrated gain and possible global-to-LDS transpose cost. Retain layout for thread ownership experiment: assign full rows to each warp to remove cross-warp softmax reductions, using 128 threads and FullRow on both attention GEMMs.

## iter-14 — High tuning child of iter-13 (de28860)
Transposed V plus 128 threads/FullRow GEMMs. Complete suite PASS; 8.444856 ms (8.413–8.471). Rejected; row ownership does not compensate for this register/layout balance.
Next structural High sibling of iter-8: keep full 64x512 score tile in registers, normalize once, then accumulate PV in 32-key chunks. This avoids online max/sum/rescaling at every key block, at the cost of more score registers and computing masked scores. On-chip score storage avoids iter-1's global S/P traffic. Actual code parent will be restored iter-8.

## iter-15 — High structural child of iter-8 (571ca47)
Full-score on-chip attention attempt. Compile FAIL: layout inference conflicts for dynamically indexed score fragment and denominator in PV chunk loop. No latency. Repair by normalizing whole score fragment once into reused K shared buffer, then slicing shared storage; BM32/128 threads keeps full-score shared storage within 64 KiB.

## iter-16 — High repair child of iter-15 (29825cd)
Full-score BM32/512, normalized probabilities reuse K LDS, PV chunks32. Complete suite PASS; 6.007560 ms (5.993–6.023). Retain structural alternative, not promoted. This is close enough to justify an intermediate decomposition: online softmax at 128-key granularity, QK reduced in 32-dimension slices and PV in 32-key slices. Larger normalization blocks reduce repeated reductions without full-sequence masked QK or BM32's low K/V reuse.

## iter-17 — High structural child of iter-16 (14ec20c)
BM64/BN128/256 attention; QK reduction chunks32, one normalization per128 keys, PV chunks32; Q shared reused for probability subtiles. Complete suite PASS; 5.149132 ms (5.144–5.206), 8.7304x. Promoted. This supports larger normalization blocks rather than full-row or simple online tile enlargement. Next BN256 under same decomposition.

## iter-18 — High tuning child of iter-17 (4abe8a2)
BN256 instead of128 with chunked QK/PV. Complete suite PASS; 5.508458 ms (5.478–5.530). Rejected for speed; increased score/LDS footprint and masked work are tradeoffs, not isolated causes.
Next restore iter-17 and revisit transposed V: now V is only32 keys per copy and lifetime/resource balance differs from iter-13.

## iter-19 — High layout child of iter-17 (4abe8a2)
Revisit transposed V for32-key PV chunks. Complete suite PASS; 5.467778 ms (5.410–5.510). Rejected for speed; no validated transpose gain in either tested decomposition.
Scheduler: lower retained iter-17. High has validated multiple structures; Native now exposes memory cache hints, instruction unrolling and load scheduling directly. Export exact iter-17, retaining its full High source in Git. Representation validation is required and is not a new optimization measurement.

## Representation edge — iter-17 High to Native
Export opt/attention/export17.json, exact High parent 4abe8a2. Required full 30-trial replay PASS. Replaced entire solution tree with validated export. No new ranking latency attributed to transfer. Native attention source shows eight serial cross-warp reductions, each with block barriers, for both max and sum. Next batch all eight row reductions into one shared-memory exchange per reduction, preserving all data dependencies.

## iter-20 — Low child of representation 4727242 (High parent iter-17)
Batch eight softmax rows: subgroup shuffle first, lane-leader shared exchange second. Complete suite PASS; 5.365053 ms (5.312–5.468). Not promoted over High iter-17. Retain exploration; result does not prove barriers unimportant. Next test installed run_batch helper, preserving original cross-warp-first reduction order with contiguous per-lane shared exchange; larger scratch (8 KiB reused) remains feasible.

## iter-21 — Low child of iter-20 (acc5cc5)
Contiguous batched cross-warp exchange with installed run_batch helper, original reduction order; scratch reused between max/sum, allocation43008 bytes. Complete suite PASS; 4.913489 ms (4.849–4.951), 9.1491x. Promoted. Barrier batching works with suitable exchange layout.
Next software-prefetch projection operands into registers one K chunk ahead while current WMMA consumes LDS; retain tile geometry, precision, output stores, grid and compiler flags. Native enables explicit prefetch lifetime/scheduling.

## iter-22 — Low child of iter-21 (2acf219)
One-chunk projection register prefetch for both operands, same128x128x64 tile. Complete suite PASS; 5.695987 ms (5.442–5.737). Rejected; added register lifetime/scheduling does not pay here. Restore iter-21.
Next attention LDS alias: K, reduction scratch and P have disjoint phases. Reuse the same16 KiB region for them, retain separate Q/P-subtile and V buffers. All transitions already have full block barriers. Allocation falls from43008 to26624 bytes, below half the actual65536 limit. This changes feasible residency without changing decomposition or arithmetic.

## iter-23 — Low child of iter-21 (2acf219)
Alias non-overlapping K/reduction/P phases;26624-byte attention LDS. Complete suite PASS; 4.704756 ms (4.603–4.933), 9.5550x. Promoted provisionally, spread overlaps lower end of iter-21 but median and most samples improve.
Next test cache policy for final streaming output only. Installed compiler lists nontemporal builtins; compile-only local probe checks gfx1201 lowering (HIP float4 struct is not accepted, Clang vector is). Keep reused intermediates/default input caching unchanged for attribution.

## iter-24 — Low child of iter-23 (754ba43)
Final output only uses non-temporal stores; installed probe emits TH_STORE_NT on gfx1201. Complete suite PASS; 4.597768 ms (4.546–4.826), 9.7773x. Retain provisionally as best median, but0.107-ms change overlaps sample spread; not a conclusive cache-policy win yet.
Scheduler rollback for combination: preserve Low branch, restore exact High iter-8 (571ca47) and export it. That validated64-key online structure has more reduction calls; batched reductions and phase aliasing may give a larger gain there. This revisits an already validated structural alternative with new local mechanisms, not an unmeasured rewrite.

## Representation edge — iter-8 High to Native
Export opt/attention/export8.json, exact High source571ca47. Required full replay PASS. Entire solution replaced by export. Confirmed actual shared_memory_per_multiprocessor=65536 and max_threads_per_multi_processor=2048 from device, in addition to prior per-block limits. Native combination will batch reductions and alias K/P/scratch (disjoint phases); keep original Q/V buffers and projection cache policy initially.

## iter-25 — Low child of representation057b661 (High parent iter-8)
Combine contiguous batched reductions with K/P/scratch aliasing; online64-key structure,36 KiB LDS. Complete suite PASS; 4.847191 ms (4.791–4.927). Retain exploration, not promoted over iter-23/24. Improvement over original iter-8 is real but does not yet beat chunked structure.
Next keep Q WMMA operands in registers for reuse across key blocks, then reuse Q's12 KiB LDS region for V. K/P/scratch remain aliased; total24 KiB. Explicit unroll preserves register indexing; block barriers protect initial Q loads before V overwrite. This couples register lifetime with shared-memory placement rather than changing attention decomposition.

## iter-26 — Low child of iter-25 (f4f2db9)
Cache Q's six WMMA operand vectors in registers, alias Q/V LDS;24 KiB LDS. Complete suite PASS; 4.842865 ms (4.812–4.879). Not promoted; indistinguishable from iter-25. Compile-only emitted metadata:185 VGPR, no spills; actual HIP occupancy query reports2 resident256-thread blocks with24576-byte LDS. Extra residency alone does not ensure a gain. Reference timing drifted to46.49 ms; comparisons remain based on unchanged ranking, not normalized ad hoc.
Next explicit V shared-memory transpose while preserving uint4 global loads. Earlier High transposes gave no gain; Native can scatter each loaded vector into transposed/swizzled LDS and replace many scalar WMMA operand reads with uint4 reads. This is a physical layout/copy control change at Low, same mathematical tiles/dependencies.

## iter-27 — Low layout child of iter-26 (3e169ff)
Vector global loads, scatter into transposed V LDS, vector PV operand reads. Complete suite PASS; 5.270981 ms (5.219–5.300), slower than retained winners. Retain only for a concrete layout repair: current swizzle depends on row low3 bits; adjacent global vectors advance V rows by8, so scatter writes concentrate on the same banks. XOR row high3 bits into the swizzle as well; vector reads remain8-half contiguous and adjacent-row read distribution is preserved. This tests a different producer/consumer layout balance rather than repeating the same transpose.

## iter-28 — Low layout child of iter-27 (8efd7cd)
XOR both low/high row bits in transposed V LDS swizzle. Complete suite PASS; 4.507715 ms (4.272–4.675), 9.9726x. Clear win over iter-27/26 supports producer bank mapping as the missing interaction. Best aggregate provisionally; cross-branch gain over iter-24 is small relative to spread. Next combine iter-24's final-output cache hint without changing attention.

## iter-29 — Low combination child of iter-28 (a3d31c5)
Final-output non-temporal store combined with online bank mapping. Complete suite PASS; 4.606032 ms (4.588–4.649). Not promoted; cache hint is inconclusive across branches and slower here. Restore default stores. Next independently test streaming FP32 activation conversion input loads with TH_LOAD_NT; converted output and reused GEMM operands retain default caching.

## iter-30 — Low cache-policy child of iter-28 (a3d31c5)
Only streaming activation-conversion input uses non-temporal load. Complete suite PASS; 4.467651 ms (4.424–4.644), 10.0621x. Retain provisional best median;0.040 ms is within spread, no proven cache-policy gain.
Scheduler rollback to High iter-8 for conversion-placement sibling. Grouped128x128 projection now reuses FP32 input tiles in cache, unlike iter-2; inline activation conversion may avoid the0.54-ms full-tensor conversion without the old streaming-reload cost. Weights remain converted once. Native winner retained in Git.

## iter-31 — High structural sibling from iter-8 (571ca47)
Inline FP32 activation conversion in grouped QKV projection; remove x-half materialization, retain once-per-forward weight conversion. Complete suite PASS; 5.394364 ms (5.278–5.442), versus original High iter-8 5.681 ms. Retain for combination; promising after cache/grid changes. Export validated structure, then combine Native attention improvements from iter-28/30. This reverses iter-3's activation conversion placement under materially changed reuse conditions; not a repeat of its original environment.

## Representation edge — iter-31 High to Native
Export opt/attention/export31.json from ecfad78; required full replay PASS. Replaced entire solution tree. Five calls instead of six; no new ranking latency assigned to transfer. Next use exact Native attention from iter-30 (same QKV/output ABI and math), renamed from kernel_4.cpp to kernel_3.cpp to match this call graph. No activation cache hint remains because its standalone conversion kernel is removed.

## iter-32 — Low combination child of representation053a68a
Inline-conversion projection from High iter-31 plus exact attention kernel from iter-30 (ABI-compatible). Complete suite PASS; 4.330150 ms (4.225–4.375), 10.3816x. Promoted; compatible improvements combine successfully.
Next QKV-output streaming policy:300-MB intermediate is consumed only after projection finishes, much larger than8-MiB L2. Non-temporal stores may reduce interference with reused weights/activation tiles. This is distinct from final-output policy; compiler probe confirms bit-preserving half stores emit TH_STORE_NT.

## iter-33 — Low cache-policy child of iter-32 (3749de7)
QKV half-output non-temporal stores. Complete suite PASS; 4.342197 ms (4.263–4.388). No measurable gain versus4.330-ms parent; reject and restore default stores. Static working-set projections alone did not predict a cache-policy benefit.
Next QKV group size4 versus8, inline FP32 input: smaller group bounds live activation/output footprint; weights remain reused across groups. Keep output projection grouping unchanged.

## iter-34 — Low tuning child of iter-32 (3749de7)
QKV M-group4 versus8. Complete suite PASS; 4.321193 ms (4.275–4.371). Inconclusive9-us median difference; retain baseline8 as equivalent, not a demonstrated promotion. Test group16 as opposite reuse/footprint balance before moving to wider projection tiles.

## iter-35 — Low tuning child of iter-34 (6df91fb)
QKV M-group16. Complete suite PASS; 4.185637 ms (4.111–4.342), 10.7400x. Retain provisional best; wider variation calls for later repeat, but plausible benefit from more weight reuse. Preserve Native branch.
Scheduler: restore High iter-31 (ecfad78) to economically test wider QKV tile geometry. Keep group8 in these High comparisons to isolate geometry from grouping; group16 remains a compatible mechanism to revisit after geometry changes. Test128x256x32 and64x256x32, both256 threads,24/20 KiB operand LDS; trade fewer activation conversions for different register/weight reuse.

## iter-36 — High tuning sibling from iter-31 (ecfad78)
QKV128x256x32/256 threads/group8, projection unchanged. Complete suite PASS; 5.315912 ms (5.247–5.427). Small gain over5.394-ms High parent overlaps spread; retain exploration. Next64x256x32 reduces accumulator footprint while changing weight reuse and block count.

## iter-37 — High tuning child of iter-36 (d7ab0e5)
QKV64x256x32/256. Complete suite PASS; 5.800072 ms (5.781–5.833). Rejected; smaller row tile is materially slower. Next restore High iter-31 and double reduction chunk to128 (128x128 tile,256 threads,64 KiB LDS) to test fewer barriers versus residency.

## iter-38 — High tuning sibling from iter-31 (ecfad78)
QKV128x128x128/256,64 KiB LDS. Complete suite PASS; 5.792287 ms (5.640–6.015). Rejected; fewer reduction barriers do not compensate for this resource balance. Next test128x256x32 with512 threads, retaining geometry of iter-36 but reducing per-thread accumulator pressure.

## iter-39 — High tuning child of iter-36 (d7ab0e5)
QKV128x256x32/512 threads. Complete suite PASS; 5.336949 ms (5.254–5.370). Inconclusive/slightly slower than256 threads; not promoted. Next128x128x64/128 threads tests the opposite ownership balance on the retained baseline geometry; output projection remains256 threads.

## iter-40 — High tuning child of iter-39 (72de921)
QKV128x128x64/128 threads. Complete suite PASS; 5.600207 ms (5.476–5.779). Rejected versus retained256-thread configurations. Next restore iter-36 and apply its128x256x32 geometry to output projection too, checking compatibility at full-forward scope.

## iter-41 — High combination child of iter-36 (d7ab0e5)
Apply128x256x32 to output projection as well. Complete suite PASS; 5.377310 ms (5.267–5.400). No gain; retain original output projection geometry.
Next structural sibling from iter-36: QKV head-major intermediate, with producer and attention consumer updated together. This keeps each head's sequence contiguous, potentially improving spatial locality for repeated K/V reads; no extra reorder kernel. Cost is more complex projection output addressing. Native attention improvements remain retained and can be adapted if this representation is worthwhile.

## iter-42 — High structural child of iter-36 (d7ab0e5)
Head-major QKV intermediate attempt. Compile FAIL: installed T.reshape computes bit count as int32; this tensor has2415919104 bits, exceeding int32 maximum. No latency. This is an API arithmetic limit, not invalid dataflow. Fix by declaring the intermediate's5D shape directly in producer/consumer signatures, avoiding reshape entirely.

## iter-43 — High repair child of iter-42 (8358789)
Declare5D QKV buffer directly, avoiding reshape bit-count overflow. Complete suite PASS; 5.529796 ms (5.505–5.556). Not promoted versus iter-36. Need cost split to distinguish producer addressing regression from attention locality effect before deciding whether Native combination is justified; diagnose unchanged measured source.

### Diagnosis / scheduler after iter-43
Matched head-major costs: attention2.894 ms, QKV1.846 ms, output projection0.627 ms, weight conversions0.094 ms. Native source still uses scalar PV LDS reads at this High point; locality change did not produce a full-forward gain and no measured evidence supports further head-major work now. Restore retained High iter-36 for export and combine its wider projection with the proven Native attention. This also lets the small geometry effect be judged under the faster full candidate.

## Representation edge — iter-36 High to Native
Export opt/attention/export36.json, exact High parent d7ab0e5; required full replay PASS. Entire solution replaced. Combine exact online Native attention from iter-35 with wider128x256x32 QKV/group8; output projection stays128x128x64/group8. No extra transfer ranking invented.

## iter-44 — Low combination child of representation6e35fbd
Wider QKV128x256x32/group8 plus exact optimized online attention from iter-35. Complete suite PASS; 4.179405 ms (4.121–4.298), 10.7560x. Equivalent to best iter-35 within variation; retain. Next group16 on this new geometry checks the known grouping interaction.

## iter-45 — Low tuning child of iter-44 (4a51d37)
Group16 on wider QKV. Complete suite PASS; 4.243117 ms (4.146–4.295). No gain; restore group8 on this geometry. Grouping benefit from iter-35 does not transfer unchanged.
Next combine retained chunked128-key attention from iter-23 with the producer/consumer V bank-layout mechanism from iter-28 and current projection. Both structures were validated at High and Low; this is a bounded cross-branch mechanism combination. K/P/reduction phase alias and batched reductions remain. Test total result rather than attributing this coupled combination to one isolated change.

## iter-46 — Low cross-branch combination from iter-44 (4a51d37)
Chunked128-key attention from iter-23 with vector V global loads, mixed-row-bit transposed LDS and vector PV reads, plus current wider inline projection. Complete suite PASS; 4.377606 ms (4.362–4.406). Rejected versus online iter-44; tested interaction does not make chunked structure faster.
Restore iter-44. Next direct Q global→WMMA-register loads avoid initial LDS staging, its address divisions and barrier, while retaining register reuse across key blocks. Each N warp duplicates Q operand reads, so cache reuse versus saved staging is measured rather than assumed.

## iter-47 — Low child of iter-44 (4a51d37)
Direct global→register Q operands, retain per-block Q reuse and all other online attention mechanisms. Complete suite PASS; 4.086940 ms (3.939–4.106), 10.9994x. Provisional best; small gain overlaps variation. Compile-only metadata202 VGPR, zero spills. Next direct K operands remove K LDS staging and one barrier; K/P/scratch region can shrink from12 to8 KiB, total20 KiB. Repeated K loads across M warps trade cache reads for staging; measure full candidate.

## iter-48 — Low child of iter-47 (5188cfb)
Direct global K WMMA operands; remove K staging/barrier,20 KiB LDS. Complete suite PASS; 4.023087 ms (3.939–4.112), 11.1740x. Provisional best; modest gain overlaps some spread. Next shorten softmax state lifetimes: rescale running numerator/denominator immediately when new max is known, eliminating separate old/alpha arrays across exponentiation/reduction. Same real arithmetic; full suite will validate changed FP32 scheduling.

## iter-49 — Low child of iter-48 (48cf6db)
Early numerator/denominator rescale shortens old/alpha lifetimes. Complete suite PASS; 4.036014 ms (3.938–4.093). Inconclusive versus4.023-ms parent, retained but not promoted. Recent attention gains are small; refresh Native call costs to choose between projection prefetch and remaining LDS layout work. Diagnose unchanged measured iter-49; High provenance is historical, not unchanged generated-code correspondence.

### Native diagnosis after iter-49
Costs: QKV1.781 ms, attention1.301 ms, output projection0.634 ms, weight conversions0.041 ms. Runtime-native mappings only; old High source is provenance. QKV is largest remaining cost. Revisit prefetch with changed premise: inline FP32 conversion and BK32 need only four uint2 activation registers, versus prior both-operand prefetch's much larger live state. Prefetch activation only, keeping weight loads unchanged. Restore best iter-48 before editing; diagnosis remains applicable to identical projection source.

## iter-50 — Low child of iter-48 (48cf6db)
Activation-only prefetch for inline-conversion QKV, BK32, four uint2 live vectors; weights unchanged. Complete suite PASS; 4.120078 ms (3.984–4.141). Rejected versus4.023-ms parent. Both broad and reduced-state prefetch configurations have now been measured under their relevant input representations.
Restore iter-48. Next probability LDS bank layout: producer warp writes two rows separated by8, which share low-row-bit swizzle. Add row bit3 into column bit4 while preserving contiguous8-half consumer reads. This is a local producer/consumer physical mapping test, no changed arithmetic.

## iter-51 — Low layout child of iter-48 (48cf6db)
Probability producer/consumer swizzle adds row bit3 to column bit4. Complete suite PASS; 3.955016 ms (3.888–3.986), 11.3663x. Provisional promotion; tighter spread supports keeping it for repeat validation. Both P and V bank mappings now measured with producer/consumer interactions.
Next specialize Python allocation/binding path for the fixed five-call graph (no tensor computation). This is an inexpensive end-to-end overhead check; diagnostic kernel sums do not by themselves prove the residual is binding cost. Native kernels and compiler flags remain verbatim.

## iter-52 — Low binding child of iter-51 (b2ce42f)
Static allocations and five explicit library calls for the fixed contract; native kernels unchanged, all input-dependent GPU work retained. Complete suite PASS; 3.912441 ms (3.782–4.142), 11.4900x. Retain provisionally; small gain and wider spread do not establish binding overhead as the cause. Next combine the earlier128x128x64/group16 projection with current attention/bindings to resolve the close projection branch comparison.

Actual occupancy check of iter-51's unchanged attention kernel:205 registers,0 local bytes,3 active256-thread blocks per reported multiprocessor with20480-byte LDS. Shorter softmax state is therefore not needed to unlock a fourth block (LDS alone permits only3); no occupancy-based reason to combine iter-49 now. Hardware count wording: device reports32 multiprocessors; this is the queried scheduling-unit count, not an assumption about nominal physical CU specifications.

## iter-53 — Low combination child of iter-52 (9c004bd)
Import128x128x64/group16 projection from iter-35 with latest attention and static bindings. Complete suite PASS; 3.831210 ms (3.372–3.965), 11.7336x. Retain provisional best; large first-sample variation requires repeat comparison.
Next local epilogue layout on the wider iter-52 projection: reuse dead operand LDS for64x256 half-output tiles, then write aligned uint4 vectors. Increase dynamic LDS24→32 KiB (still at most two blocks by shared-memory capacity), two output phases. This reduces scalar global store instruction count but adds LDS traffic/barriers; measure. Narrow tile can stage its entire output in its existing32 KiB, a useful second resource configuration.

## iter-54 — Low epilogue child of iter-52 (9c004bd)
Wider QKV stages output in two64x256 half tiles,32 KiB LDS, aligned uint4 global stores. Complete suite PASS; 4.231859 ms (4.098–4.387). Rejected; extra shared traffic/phases outweigh tested coalescing gain. Original generated C-fragment mapping was checked against the retained source. Next narrow iter-53 can stage its entire128x128 output at once in existing32 KiB, avoiding partial-wave phases and additional allocation.

## iter-55 — Low epilogue child of iter-53 (6428f5e)
Narrow QKV stages full128x128 output in existing32 KiB, one producer/copy phase. Complete suite PASS; 4.102439 ms (4.011–4.200). Rejected. Both full-tile and phased vector-store configurations lose; do not extrapolate coalescing into a gain. Original final-output projection already writes full32-bit elements; extra staging there has lower expected value after these results.
Restore iter-53. Next binding-only workspace reuse: four intermediate allocations cached per device/stream, fresh output each forward, all input-dependent kernels still execute. A CPU lock protects enqueue ordering for concurrent calls; different streams get separate workspaces. This tests allocation overhead without precomputed tensors or skipped computation.

## iter-56 — Low binding child of iter-53 (6428f5e)
Per-device/stream reusable intermediate allocations, fresh output, lock-protected enqueue. Complete suite PASS; 4.064620 ms (4.002–4.298). Rejected versus static fresh allocations. Restore iter-53. Next warp-local 8x8 half transpose packs QKV stores without LDS or barriers; this directly distinguishes vector-store benefit from the extra shared traffic of iter-54/55. Preserve all GEMM arithmetic and resource allocation.

## iter-57 — Low epilogue child of iter-53 (6428f5e)
Warp-local packed half 8x8 transpose, uint4 global stores, no extra LDS/barriers. Complete suite PASS; 4.139452 ms (3.874–4.315). Rejected. Together with staged full-tile and phased stores, this tests materially different producer/consumer placements; no measured benefit supports further output-packing work now.
Next repeat the close retained narrow and wide direct-store candidates under unchanged evaluator; best single aggregates overlap substantial timing spread.

## iter-58 — Low unchanged repeat of iter-53 (6428f5e)
Restored entire solution verbatim. Complete suite PASS; 3.880321 ms (3.802–4.045), 11.5851x fixed reference. Confirms narrow candidate near its original3.831-ms aggregate, with repeatable high first-sample variation. Retain for final selection; next unchanged wide iter-52 comparison.

## iter-59 — Low unchanged repeat of iter-52 (9c004bd)
Restored entire wide solution verbatim. Complete suite PASS; 3.896413 ms (3.859–4.028), 11.5372x fixed reference. Equivalent to narrow repeat within spread. Retain as alternative; select narrow iter-53 for final, since both its original and repeat aggregates are lower, without claiming a statistically established geometry advantage.

## Reassessment and stop decision
No latency target was supplied; current time is around11:23 UTC, before the11:54 cutoff. Stop for low expected value from remaining supported opportunities, not a shortened time budget or proven hardware floor.
Measured structural coverage includes explicit scores/probabilities, online attention with multiple query/key geometries and warp ownerships, full-row on-chip attention,128/256-key normalization chunks, preconverted versus inline activations, and head-major intermediate storage. Chunked and online branches were lowered, optimized, and combined with compatible later mechanisms. Dominant QKV coverage includes64/128-row and128/256-column tiles,32/64/128 reduction chunks,128/256/512 threads where feasible, grouped traversal, both-operand and activation-only prefetch under changed representations, and direct/scalar, LDS-staged/full or phased, and warp-packed epilogues. Output projection geometry and streaming cache policies were also measured. Attention coverage includes batched reductions, lifetime/phase aliasing, register Q reuse, direct Q/K operands, V/P producer-consumer bank mappings and combination with alternate normalization structure. Bindings and intermediate reuse were measured end to end.
The most recent diagnosis places QKV around1.78 ms, attention1.30 ms and output projection0.63 ms; these guide direction, not a floor or current exact decomposition. Remaining full-forward fusion would require cross-block producer/consumer coordination or duplicated QKV work; current evidence does not support that expense. Splitting attention adds merge traffic to a grid already containing8192 blocks on32 reported multiprocessors, without an observed parallelism shortage. Larger double-buffered projection designs introduce resource/inline-conversion costs; measured prefetch variants and reduction/resource alternatives give no concrete favorable configuration to pursue now. Weight conversion totals only about0.04 ms, below observed total timing variation, so fusion there has limited expected value. These are opportunity assessments, not proofs that all variants are exhausted. Restore complete iter-53 solution from Git, then run mandatory final suite without source changes.

## final — exact restored iter-53 (6428f5e), Low
Mandatory `bash scripts/bench.sh final`: compiled, complete30-trial correctness PASS. Median4.137706757 ms, samples3.998–4.163 ms. Fixed-reference44.953800201-ms speedup10.8644x; reference median44.953800201 ms. Final timing is slower than selection repeats; no source change or unvalidated substitution was made. Report final result, retaining original/repeat evidence and alternative wide branch. Final solution exactly matches selected node. Generated exploration exports, assembly and occupancy probes moved into ignored `.cache/exploration-artifacts`; committed source/records and evaluator trajectories remain available. All benchmark scripts and reference remain unchanged.
