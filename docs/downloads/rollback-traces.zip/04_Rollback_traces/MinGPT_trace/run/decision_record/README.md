# MinGPT decision record

| File or directory | Contents |
|---|---|
| `agent-output.txt` | Readable transcript of the available conversation events |
| `agent-events.jsonl` | Events in source order with event-line references |
| `decision_index.csv` | Evaluation-to-event, output, and candidate links |
| `iteration_notes.md` | Parent choices, edits, measurements, and reasons for retaining or rejecting candidates |
| `diagnostics/` | Diagnosis reports for iter-2, iter-8, iter-43, and iter-49 |

Main evaluations use three warmups followed by five timed forwards, median aggregation, and the AMD full-forward HIP-event metric. Correctness uses N(0,1) activation inputs and thirty checks across seed bases 42, 43, and 50000.

The iter-8 diagnosis includes the Figure 3 whole-attention-call latency of 2.786430 ms and its High/Native source association. This call-group cost is separate from complete-forward latency. Hardware counter counts and ambiguous-symbol associations retain their recorded diagnostic scope.
