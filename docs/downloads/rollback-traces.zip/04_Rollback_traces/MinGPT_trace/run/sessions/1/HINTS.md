# Paper protocol hints


Ours owns High (TileLang) and Low (HIP C++) in this same conversation. Start empty and choose the initial level using the supplied TileCas skill; follow that skill for diagnosis, stay/lower/rollback and final selection. High prohibits torch imports/framework computation; use target="hip", execution_backend="cython". Low edits native source with allocation/bindings only, without TileLang/Triton regeneration or framework/external-operator fallback. To roll back, restore the entire High solution and remove leftover native sources.
Target AMD Radeon AI PRO R9700, gfx1201, ROCm 7.14, FP32 inputs.
Implement solution/ModelNew.py exposing ModelNew with to(), __call__(), forward().
Read reference.py for the complete task. Input distribution N(0,1); seeds 42,43,50000; ten correctness trials per seed; atol=rtol=1e-3; three warmups followed by five HIP-event timed forwards in one timing block at input seed 42; report the median of five samples. Reference and candidate use the same timing inputs and protocol. The three correctness seed bases are separate from timing repetitions.
Use only bash scripts/bench.sh LABEL for evaluation; do not edit reference.py or scripts/. It remeasures the reference and includes all GPU work in forward.
Native compute may use authored HIP and TileLang HIP headers; no rocBLAS/hipBLAS/MIOpen, CK or complete attention implementations.
Preserve every input dependency and reference mathematics. No distribution-specific approximation.
Read-only platform references: /home/xiaoxinyu/venvs/dsl-native-opt/lib/python3.12/site-packages/tilelang; /home/xiaoxinyu/venvs/dsl-native-opt/lib/python3.12/site-packages/_rocm_sdk_devel/include.
Work in this workspace only; do not read sibling experiments or optimizer histories. Work alone, no delegation. Do not calculate hashes/checksums.
Nsight Compute is unavailable on AMD; scripts/bench.sh owns ranking.

Task: KernelBench Level 3 MinGPTCausalAttention, full forward including QKV and output projections.
Original dimensions: batch 128, sequence 512, embedding 768, 8 heads (head dimension 96); causal mask; dropout probabilities zero.
Use the same get_init_inputs constructor arguments as reference.py. ModelNew.forward receives five tensors:
x [128,512,768], qkv_weight [2304,768], qkv_bias [2304], projection_weight [768,768], projection_bias [768].
Weights use PyTorch Linear's [out_features,in_features] convention. They are fixed parameters from the original seed-42 initialization, passed explicitly and identically to both implementations; do not reinitialize or mutate them. Activations use N(0,1).
The appended reference adapter only supplies these parameter bindings to the original forward. Preserve all projections, bias additions, scaling, causal masking, softmax, head reassembly and output semantics. No precomputed outputs or sibling-run imports.
Use python scripts/diagnose.py with no arguments only when existing evidence leaves the next experiment unclear. Neither first correctness nor a new iteration triggers diagnosis. The tool reuses source/reference/protocol-matched evidence or collects missing High provenance, call-group costs and available ROCm counters, and reports all calls. It never exports authored Low. Costs are diagnostic, not ranking or a hardware floor. Counter summaries aggregate by symbol and include warmup; ambiguous associations remain unknown. Native changes retain historical High provenance without claiming unchanged correspondence. Export via scripts/export.py performs full Native replay validation; do not add a duplicate transfer baseline.
Run window: 2026-09-26 09:54 to 11:54 UTC, cut off at the end whatever state you are in. `date -u` for the time now.
