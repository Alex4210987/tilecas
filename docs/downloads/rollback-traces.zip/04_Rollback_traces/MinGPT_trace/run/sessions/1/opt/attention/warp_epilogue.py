from pathlib import Path
p=Path('solution/kernel_2.cpp')
s=p.read_text(); a=s.index('  #pragma unroll\n  for (int i_5 = 0;'); b=s.index('\n}\n\n\n#ifdef',a)
s=s[:a]+'''  const int tid = threadIdx.x;
  #pragma unroll
  for (int g = 0; g < 8; ++g) {
    unsigned w[4];
    const int bc = blockIdx.y * 128 + (tid >> 7) * 64 + (g % 4) * 16 + (tid & 15);
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
      half_t lo = (half_t)(c[g*8+j*2] + B[bc]);
      half_t hi = (half_t)(c[g*8+j*2+1] + B[bc]);
      w[j] = (unsigned)__builtin_bit_cast(unsigned short, lo) | ((unsigned)__builtin_bit_cast(unsigned short, hi) << 16);
    }
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
      unsigned other = __shfl_xor(w[j], 1, 8);
      w[j] = (tid & 1) ? ((other >> 16) | (w[j] & 0xffff0000u)) : ((w[j] & 0xffffu) | (other << 16));
    }
    #pragma unroll
    for (int j = 0; j < 4; j += 2) {
      unsigned other = __shfl_xor((tid & 2) ? w[j] : w[j+1], 2, 8);
      w[j] = (tid & 2) ? other : w[j];
      w[j+1] = (tid & 2) ? w[j+1] : other;
    }
    #pragma unroll
    for (int j = 0; j < 2; ++j) {
      unsigned other = __shfl_xor((tid & 4) ? w[j] : w[j+2], 4, 8);
      w[j] = (tid & 4) ? other : w[j];
      w[j+2] = (tid & 4) ? w[j+2] : other;
    }
    int row = ((tid & 127) >> 5)*32 + (g/4)*16 + ((tid & 31)>>4)*8 + (tid & 7);
    int col = (tid>>7)*64 + (g%4)*16 + (tid & 8);
    *(uint4*)(Y + (blockIdx.x*128+row)*2304 + blockIdx.y*128+col) = make_uint4(w[0],w[1],w[2],w[3]);
  }'''+s[b:];p.write_text(s)
