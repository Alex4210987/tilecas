import tilelang
import tilelang.language as T

@tilelang.jit(out_idx=[3], target='hip', execution_backend='cython')
def linear(N: int, out_dtype: str, BM: int=128, BN: int=128, BK: int=64):
    @T.prim_func
    def main(X:T.Tensor((128,512,768),'float16'), W:T.Tensor((N,768),'float16'), B:T.Tensor((N,),'float32'), Y:T.Tensor((128,512,N),out_dtype)):
        with T.Kernel(65536//BM,T.ceildiv(N,BN),threads=256) as (bm,bn):
            T.use_swizzle(panel_size=8,order="column")
            a=T.alloc_shared((BM,BK),'float16')
            b=T.alloc_shared((BN,BK),'float16')
            c=T.alloc_fragment((BM,BN),'float32')
            T.clear(c)
            for k in T.Pipelined(768//BK,num_stages=2):
                for i,j in T.Parallel(BM,BK):
                    a[i,j]=X[bm//(512//BM),(bm%(512//BM))*BM+i,k*BK+j]
                for i,j in T.Parallel(BN,BK):
                    b[i,j]=W[bn*BN+i,k*BK+j]
                T.gemm(a,b,c,transpose_B=True)
            for i,j in T.Parallel(BM,BN):
                Y[bm//(512//BM),(bm%(512//BM))*BM+i,bn*BN+j]=c[i,j]+B[bn*BN+j]
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def attention(BM: int=64):
    @T.prim_func
    def main(Q:T.Tensor((128,512,2304),'float16'), Y:T.Tensor((128,512,768),'float16')):
        with T.Kernel(512//BM,1024,threads=128) as (mi,bh):
            q=T.alloc_shared((BM,96),'float16')
            k=T.alloc_shared((64,96),'float16')
            v=T.alloc_shared((64,96),'float16')
            p=T.alloc_shared((BM,64),'float16')
            s=T.alloc_fragment((BM,64),'float32')
            o=T.alloc_fragment((BM,96),'float32')
            m=T.alloc_fragment((BM,),'float32')
            old=T.alloc_fragment((BM,),'float32')
            alpha=T.alloc_fragment((BM,),'float32')
            l=T.alloc_fragment((BM,),'float32')
            rows=T.alloc_fragment((BM,),'float32')
            T.fill(m,-T.infinity('float32'))
            T.clear(l)
            T.clear(o)
            for i,j in T.Parallel(BM,96):
                q[i,j]=Q[bh//8,mi*BM+i,(bh%8)*96+j]
            for nb in T.serial(T.ceildiv((mi+1)*BM,64)):
                for i,j in T.Parallel(64,96):
                    k[i,j]=Q[bh//8,nb*64+i,768+(bh%8)*96+j]
                    v[i,j]=Q[bh//8,nb*64+i,1536+(bh%8)*96+j]
                T.clear(s)
                T.gemm(q,k,s,transpose_B=True)
                for i,j in T.Parallel(BM,64):
                    s[i,j]=T.if_then_else(nb*64+j<=mi*BM+i,s[i,j]*0.10206207261596575,-T.infinity('float32'))
                T.copy(m,old)
                T.reduce_max(s,m,dim=1,clear=False)
                for i in T.Parallel(BM):
                    alpha[i]=T.exp(old[i]-m[i])
                for i,j in T.Parallel(BM,64):
                    s[i,j]=T.exp(s[i,j]-m[i])
                T.reduce_sum(s,rows,dim=1)
                for i in T.Parallel(BM):
                    l[i]=l[i]*alpha[i]+rows[i]
                for i,j in T.Parallel(BM,96):
                    o[i,j]=o[i,j]*alpha[i]
                T.copy(s,p)
                T.gemm(p,v,o)
            for i,j in T.Parallel(BM,96):
                Y[bh//8,mi*BM+i,(bh%8)*96+j]=o[i,j]/l[i]
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def convert(shape):
    size=1
    for d in shape: size*=d
    @T.prim_func
    def main(X:T.Tensor(shape,'float32'), Y:T.Tensor(shape,'float16')):
        with T.Kernel(T.ceildiv(size,1024),threads=256) as b:
            for i in T.Parallel(1024):
                T.reshape(Y,(size,))[b*1024+i]=T.reshape(X,(size,))[b*1024+i]
    return main

class ModelNew:
    def __init__(self,*args):
        self.cx=convert((128,512,768))
        self.cw=convert((2304,768))
        self.cp=convert((768,768))
        self.qkv=linear(2304,'float16')
        self.attn=attention()
        self.proj=linear(768,'float32')
    def to(self,*args,**kwargs): return self
    def forward(self,x,qkv_weight,qkv_bias,projection_weight,projection_bias):
        xh=self.cx(x)
        wh=self.cw(qkv_weight)
        ph=self.cp(projection_weight)
        q=self.qkv(xh,wh,qkv_bias)
        y=self.attn(q)
        return self.proj(y,ph,projection_bias)
    __call__=forward
