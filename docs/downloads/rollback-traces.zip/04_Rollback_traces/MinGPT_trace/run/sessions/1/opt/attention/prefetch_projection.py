from pathlib import Path
for name in ['kernel_3.cpp','kernel_5.cpp']:
    p=Path('solution')/name
    s=p.read_text()
    start=s.index('  for (int k = 0; k < 12; ++k) {')
    end=s.index('    {\n      half_t A_local',start)
    old=s[start:end]
    lines=[line for line in old.splitlines() if ' = *(uint4*)(' in line]
    store_a,load_a=lines[0].strip().split(' = ',1)
    store_b,load_b=lines[1].strip().split(' = ',1)
    s=s[:start]+'''  uint4 pre_a[4], pre_b[4];
  #pragma unroll
  for (int i_1=0;i_1<4;++i_1) pre_a[i_1] = '''+load_a.replace('(k * 64)','0')+'''
  #pragma unroll
  for (int i_2=0;i_2<4;++i_2) pre_b[i_2] = '''+load_b.replace('(k * 64)','0')+'''
  for (int k = 0; k < 12; ++k) {
    __syncthreads();
    #pragma unroll
    for (int i_1=0;i_1<4;++i_1) '''+store_a+''' = pre_a[i_1];
    #pragma unroll
    for (int i_2=0;i_2<4;++i_2) '''+store_b+''' = pre_b[i_2];
'''+s[end:]
    anchor='      __syncthreads();\n      for (int ki = 0; ki < 4; ++ki) {'
    repl='''      __syncthreads();
      if (k+1<12) {
        #pragma unroll
        for (int i_1=0;i_1<4;++i_1) pre_a[i_1] = '''+load_a.replace('(k * 64)','((k+1) * 64)')+'''
        #pragma unroll
        for (int i_2=0;i_2<4;++i_2) pre_b[i_2] = '''+load_b.replace('(k * 64)','((k+1) * 64)')+'''
      }
      for (int ki = 0; ki < 4; ++ki) {'''
    assert anchor in s
    s=s.replace(anchor,repl)
    p.write_text(s)
