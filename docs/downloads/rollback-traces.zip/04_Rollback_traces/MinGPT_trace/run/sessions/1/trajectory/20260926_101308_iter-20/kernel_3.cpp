#include <hip/hip_runtime.h>
#include <tl_templates/hip/gemm.h>
#include <tl_templates/hip/copy.h>
#include <tl_templates/hip/reduce.h>
#include <tl_templates/hip/scan.h>
#include <tl_templates/hip/ldsm.h>
#include <tl_templates/hip/threadblock_swizzle.h>
#include <tl_templates/hip/debug.h>

extern "C" __global__ void __launch_bounds__(256) main_kernel(float* __restrict__ B, half_t* __restrict__ W, half_t* __restrict__ X, half_t* __restrict__ Y) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* a = ((void*)((char*)buf_dyn_shmem + 0));
  void* b = ((void*)((char*)buf_dyn_shmem + 16384));
  float c[64];
  const dim3 blockIdx = tl::rasterization2DColumn<8>();
  #pragma unroll
  for (int i = 0; i < 16; ++i) {
    float broadcast_var = 0.000000e+00f;
    *(float4*)(c + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  for (int k = 0; k < 12; ++k) {
    __syncthreads();
    #pragma unroll
    for (int i_1 = 0; i_1 < 4; ++i_1) {
      *(uint4*)(((half_t*)a) + (((((i_1 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))) = *(uint4*)(X + (((((((int)blockIdx.x) * 98304) + (i_1 * 24576)) + ((((int)threadIdx.x) >> 3) * 768)) + (k * 64)) + ((((int)threadIdx.x) & 7) * 8)));
    }
    #pragma unroll
    for (int i_2 = 0; i_2 < 4; ++i_2) {
      *(uint4*)(((half_t*)b) + (((((i_2 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))) = *(uint4*)(W + (((((((int)blockIdx.y) * 98304) + (i_2 * 24576)) + ((((int)threadIdx.x) >> 3) * 768)) + (k * 64)) + ((((int)threadIdx.x) & 7) * 8)));
    }
    {
      half_t A_local[16];
      half_t B_local[32];
      __syncthreads();
      for (int ki = 0; ki < 4; ++ki) {
        for (int i_3 = 0; i_3 < 2; ++i_3) {
          *(uint4*)(A_local + (i_3 * 8)) = *(uint4*)(((half_t*)a) + ((((((((((int)threadIdx.x) & 127) >> 5) * 2048) + (i_3 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)));
        }
        for (int j = 0; j < 4; ++j) {
          *(uint4*)(B_local + (j * 8)) = *(uint4*)(((half_t*)b) + (((((((((int)threadIdx.x) >> 7) * 4096) + (j * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)));
        }
        for (int i_4 = 0; i_4 < 2; ++i_4) {
          for (int j_1 = 0; j_1 < 4; ++j_1) {
            {
      typedef __attribute__((__vector_size__(8 * sizeof(__fp16)))) __fp16 tl_v8f16;
      typedef __attribute__((__vector_size__(8 * sizeof(float)))) float tl_v8f32;
      *((tl_v8f32*)c + ((i_4 * 4) + j_1)) = __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(
          *((tl_v8f16*)A_local + i_4),
          *((tl_v8f16*)B_local + j_1),
          *((tl_v8f32*)c + ((i_4 * 4) + j_1)));
    };
          }
        }
      }
    }
  }
  #pragma unroll
  for (int i_5 = 0; i_5 < 64; ++i_5) {
    Y[(((((((((((int)blockIdx.x) * 294912) + (((((int)threadIdx.x) & 127) >> 5) * 73728)) + ((i_5 >> 5) * 36864)) + (((((int)threadIdx.x) & 31) >> 4) * 18432)) + ((i_5 & 7) * 2304)) + (((int)blockIdx.y) * 128)) + ((((int)threadIdx.x) >> 7) * 64)) + (((i_5 & 31) >> 3) * 16)) + (((int)threadIdx.x) & 15))] = ((half_t)(c[i_5] + B[((((((int)blockIdx.y) * 128) + ((((int)threadIdx.x) >> 7) * 64)) + (((i_5 & 31) >> 3) * 16)) + (((int)threadIdx.x) & 15))]));
  }
}


#ifdef _WIN32
#define TL_EXPORT __declspec(dllexport)
#else
#define TL_EXPORT
#endif

#define ERROR_BUF_SIZE 1024
static char error_buf[ERROR_BUF_SIZE];

extern "C" TL_EXPORT const char* get_last_error() {
    return error_buf;
}

extern "C" TL_EXPORT int init() {
    error_buf[0] = '\0';
    
    int device_main_kernel = 0;
    hipError_t dev_res_main_kernel = hipGetDevice(&device_main_kernel);
    if (dev_res_main_kernel != hipSuccess) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to get HIP device for main_kernel: %s", hipGetErrorString(dev_res_main_kernel));
        return -1;
    }
    int max_smem_main_kernel = 0;
    hipError_t attr_res_main_kernel = hipDeviceGetAttribute(&max_smem_main_kernel, hipDeviceAttributeMaxSharedMemoryPerBlock, device_main_kernel);
    if (attr_res_main_kernel != hipSuccess || max_smem_main_kernel <= 0) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to query HIP max shared memory for main_kernel: %s", hipGetErrorString(attr_res_main_kernel));
        return -1;
    }
    if (32768 > max_smem_main_kernel) {
        snprintf(
            error_buf,
            ERROR_BUF_SIZE,
            "Requested dynamic shared memory %d exceeds device limit %d for main_kernel",
            32768,
            max_smem_main_kernel
        );
        return -1;
    }
    return 0;

    return 0;
}

extern "C" TL_EXPORT int call(half_t* __restrict__ X, half_t* __restrict__ W, float* __restrict__ B, half_t* __restrict__ Y, hipStream_t stream=hipStreamDefault) {
	main_kernel<<<dim3(512, 18, 1), dim3(256, 1, 1), 32768, stream>>>(B, W, X, Y);
	TILELANG_CHECK_LAST_ERROR("main_kernel");

	return 0;
}
