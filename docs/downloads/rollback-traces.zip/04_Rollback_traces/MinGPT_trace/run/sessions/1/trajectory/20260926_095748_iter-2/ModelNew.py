import tilelang
import tilelang.language as T

@tilelang.jit(out_idx=[3], target='hip', execution_backend='cython')
def linear(N: int, out_dtype: str):
    @T.prim_func
    def main(X:T.Tensor((128,512,768),'float32'), W:T.Tensor((N,768),'float32'), B:T.Tensor((N,),'float32'), Y:T.Tensor((128,512,N),out_dtype)):
        with T.Kernel(1024,T.ceildiv(N,64),threads=128) as (bm,bn):
            a=T.alloc_shared((64,32),'float16')
            b=T.alloc_shared((64,32),'float16')
            c=T.alloc_fragment((64,64),'float32')
            T.clear(c)
            for k in T.Pipelined(24,num_stages=2):
                for i,j in T.Parallel(64,32):
                    a[i,j]=X[bm//8,(bm%8)*64+i,k*32+j]
                    b[i,j]=W[bn*64+i,k*32+j]
                T.gemm(a,b,c,transpose_B=True)
            for i,j in T.Parallel(64,64):
                Y[bm//8,(bm%8)*64+i,bn*64+j]=c[i,j]+B[bn*64+j]
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def scores():
    @T.prim_func
    def main(Q:T.Tensor((128,512,2304),'float16'), S:T.Tensor((128,8,512,512),'float32')):
        with T.Kernel(8,8,1024,threads=128) as (mi,ni,bh):
            a=T.alloc_shared((64,32),'float16')
            b=T.alloc_shared((64,32),'float16')
            c=T.alloc_fragment((64,64),'float32')
            T.clear(c)
            for k in T.Pipelined(3,num_stages=2):
                for i,j in T.Parallel(64,32):
                    a[i,j]=Q[bh//8,mi*64+i,(bh%8)*96+k*32+j]
                    b[i,j]=Q[bh//8,ni*64+i,768+(bh%8)*96+k*32+j]
                T.gemm(a,b,c,transpose_B=True)
            for i,j in T.Parallel(64,64):
                S[bh//8,bh%8,mi*64+i,ni*64+j]=T.if_then_else(ni*64+j<=mi*64+i,c[i,j]*0.10206207261596575,-T.infinity('float32'))
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def softmax():
    @T.prim_func
    def main(S:T.Tensor((128,8,512,512),'float32'), P:T.Tensor((128,8,512,512),'float16')):
        with T.Kernel(512,1024,threads=128) as (m,bh):
            a=T.alloc_fragment((512,),'float32')
            mx=T.alloc_fragment((1,),'float32')
            sm=T.alloc_fragment((1,),'float32')
            T.copy(S[bh//8,bh%8,m,:],a)
            T.reduce_max(a,mx,dim=0)
            for i in T.Parallel(512):
                a[i]=T.exp(a[i]-mx[0])
            T.reduce_sum(a,sm,dim=0)
            for i in T.Parallel(512):
                P[bh//8,bh%8,m,i]=a[i]/sm[0]
    return main

@tilelang.jit(out_idx=[2],target='hip',execution_backend='cython')
def values():
    @T.prim_func
    def main(P:T.Tensor((128,8,512,512),'float16'), Q:T.Tensor((128,512,2304),'float16'), Y:T.Tensor((128,512,768),'float32')):
        with T.Kernel(8,3,1024,threads=128) as (mi,ni,bh):
            a=T.alloc_shared((64,32),'float16')
            b=T.alloc_shared((32,32),'float16')
            c=T.alloc_fragment((64,32),'float32')
            T.clear(c)
            for k in T.Pipelined(16,num_stages=2):
                T.copy(P[bh//8,bh%8,mi*64:mi*64+64,k*32:k*32+32],a)
                for i,j in T.Parallel(32,32):
                    b[i,j]=Q[bh//8,k*32+i,1536+(bh%8)*96+ni*32+j]
                T.gemm(a,b,c)
            for i,j in T.Parallel(64,32):
                Y[bh//8,mi*64+i,(bh%8)*96+ni*32+j]=c[i,j]
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def attention():
    @T.prim_func
    def main(Q:T.Tensor((128,512,2304),'float16'), Y:T.Tensor((128,512,768),'float32')):
        with T.Kernel(16,1024,threads=128) as (mi,bh):
            q=T.alloc_shared((32,96),'float16')
            k=T.alloc_shared((64,96),'float16')
            v=T.alloc_shared((64,96),'float16')
            p=T.alloc_shared((32,64),'float16')
            s=T.alloc_fragment((32,64),'float32')
            o=T.alloc_fragment((32,96),'float32')
            m=T.alloc_fragment((32,),'float32')
            old=T.alloc_fragment((32,),'float32')
            alpha=T.alloc_fragment((32,),'float32')
            l=T.alloc_fragment((32,),'float32')
            rows=T.alloc_fragment((32,),'float32')
            T.fill(m,-T.infinity('float32'))
            T.clear(l)
            T.clear(o)
            for i,j in T.Parallel(32,96):
                q[i,j]=Q[bh//8,mi*32+i,(bh%8)*96+j]
            for nb in T.serial(T.ceildiv((mi+1)*32,64)):
                for i,j in T.Parallel(64,96):
                    k[i,j]=Q[bh//8,nb*64+i,768+(bh%8)*96+j]
                    v[i,j]=Q[bh//8,nb*64+i,1536+(bh%8)*96+j]
                T.clear(s)
                T.gemm(q,k,s,transpose_B=True)
                for i,j in T.Parallel(32,64):
                    s[i,j]=T.if_then_else(nb*64+j<=mi*32+i,s[i,j]*0.10206207261596575,-T.infinity('float32'))
                T.copy(m,old)
                T.reduce_max(s,m,dim=1,clear=False)
                for i in T.Parallel(32):
                    alpha[i]=T.exp(old[i]-m[i])
                for i,j in T.Parallel(32,64):
                    s[i,j]=T.exp(s[i,j]-m[i])
                T.reduce_sum(s,rows,dim=1)
                for i in T.Parallel(32):
                    l[i]=l[i]*alpha[i]+rows[i]
                for i,j in T.Parallel(32,96):
                    o[i,j]=o[i,j]*alpha[i]
                T.copy(s,p)
                T.gemm(p,v,o)
            for i,j in T.Parallel(32,96):
                Y[bh//8,mi*32+i,(bh%8)*96+j]=o[i,j]/l[i]
    return main

class ModelNew:
    def __init__(self,*args):
        self.qkv=linear(2304,'float16')
        self.attn=attention()
        self.proj=linear(768,'float32')
    def to(self,*args,**kwargs): return self
    def forward(self,x,qkv_weight,qkv_bias,projection_weight,projection_bias):
        q=self.qkv(x,qkv_weight,qkv_bias)
        y=self.attn(q)
        return self.proj(y,projection_weight,projection_bias)
    __call__=forward
