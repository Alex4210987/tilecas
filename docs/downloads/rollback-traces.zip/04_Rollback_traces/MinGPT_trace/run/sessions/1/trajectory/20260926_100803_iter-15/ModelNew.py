import tilelang
import tilelang.language as T

@tilelang.jit(out_idx=[3], target='hip', execution_backend='cython')
def linear(N: int, out_dtype: str, BM: int=128, BN: int=128, BK: int=64):
    @T.prim_func
    def main(X:T.Tensor((128,512,768),'float16'), W:T.Tensor((N,768),'float16'), B:T.Tensor((N,),'float32'), Y:T.Tensor((128,512,N),out_dtype)):
        with T.Kernel(65536//BM,T.ceildiv(N,BN),threads=256) as (bm,bn):
            T.use_swizzle(panel_size=8,order="column")
            a=T.alloc_shared((BM,BK),'float16')
            b=T.alloc_shared((BN,BK),'float16')
            c=T.alloc_fragment((BM,BN),'float32')
            T.clear(c)
            for k in T.Pipelined(768//BK,num_stages=2):
                for i,j in T.Parallel(BM,BK):
                    a[i,j]=X[bm//(512//BM),(bm%(512//BM))*BM+i,k*BK+j]
                for i,j in T.Parallel(BN,BK):
                    b[i,j]=W[bn*BN+i,k*BK+j]
                T.gemm(a,b,c,transpose_B=True)
            for i,j in T.Parallel(BM,BN):
                Y[bm//(512//BM),(bm%(512//BM))*BM+i,bn*BN+j]=c[i,j]+B[bn*BN+j]
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def attention():
    @T.prim_func
    def main(Q:T.Tensor((128,512,2304),'float16'), Y:T.Tensor((128,512,768),'float16')):
        with T.Kernel(8,1024,threads=256) as (mi,bh):
            q=T.alloc_shared((64,32),'float16')
            k=T.alloc_shared((512,32),'float16')
            v=T.alloc_shared((32,96),'float16')
            p=T.alloc_shared((64,32),'float16')
            s=T.alloc_fragment((64,512),'float32')
            o=T.alloc_fragment((64,96),'float32')
            m=T.alloc_fragment((64,),'float32')
            l=T.alloc_fragment((64,),'float32')
            T.clear(s)
            T.clear(o)
            for d in T.serial(3):
                for i,j in T.Parallel(64,32):
                    q[i,j]=Q[bh//8,mi*64+i,(bh%8)*96+d*32+j]
                for i,j in T.Parallel(512,32):
                    k[i,j]=Q[bh//8,i,768+(bh%8)*96+d*32+j]
                T.gemm(q,k,s,transpose_B=True)
            for i,j in T.Parallel(64,512):
                s[i,j]=T.if_then_else(j<=mi*64+i,s[i,j]*0.10206207261596575,-T.infinity('float32'))
            T.reduce_max(s,m,dim=1)
            for i,j in T.Parallel(64,512):
                s[i,j]=T.exp(s[i,j]-m[i])
            T.reduce_sum(s,l,dim=1)
            for nb in T.serial((mi+1)*2):
                for i,j in T.Parallel(64,32):
                    p[i,j]=s[i,nb*32+j]/l[i]
                for i,j in T.Parallel(32,96):
                    v[i,j]=Q[bh//8,nb*32+i,1536+(bh%8)*96+j]
                T.gemm(p,v,o)
            for i,j in T.Parallel(64,96):
                Y[bh//8,mi*64+i,(bh%8)*96+j]=o[i,j]
    return main

@tilelang.jit(out_idx=[1],target='hip',execution_backend='cython')
def convert(shape):
    size=1
    for d in shape: size*=d
    @T.prim_func
    def main(X:T.Tensor(shape,'float32'), Y:T.Tensor(shape,'float16')):
        with T.Kernel(T.ceildiv(size,1024),threads=256) as b:
            for i in T.Parallel(1024):
                T.reshape(Y,(size,))[b*1024+i]=T.reshape(X,(size,))[b*1024+i]
    return main

class ModelNew:
    def __init__(self,*args):
        self.cx=convert((128,512,768))
        self.cw=convert((2304,768))
        self.cp=convert((768,768))
        self.qkv=linear(2304,'float16')
        self.attn=attention()
        self.proj=linear(768,'float32')
    def to(self,*args,**kwargs): return self
    def forward(self,x,qkv_weight,qkv_bias,projection_weight,projection_bias):
        xh=self.cx(x)
        wh=self.cw(qkv_weight)
        ph=self.cp(projection_weight)
        q=self.qkv(xh,wh,qkv_bias)
        y=self.attn(q)
        return self.proj(y,ph,projection_bias)
    __call__=forward
