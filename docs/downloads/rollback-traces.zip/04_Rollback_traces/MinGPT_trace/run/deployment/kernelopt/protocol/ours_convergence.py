"""Compact measured search history for joint diagnosis and representation choice.

This is evidence compression, not a destination policy or an extra stopping gate.
"""
import math
import re
from ours_feedback import profile_is_current


MATERIAL_GAIN_FRACTION = .03
RECENT_ATTEMPT_WINDOW = 3
RECENT_EDIT_WINDOW = 5
ITERATION_MESSAGE = re.compile(r'\[iter\s*\d+\]', re.I)


def positive(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def measured_evaluation_seconds(raw):
    """Return the last complete evaluator wall-time observation."""
    matches = re.findall(r'^EVAL_WALL_SECONDS:\s*([^\n]+)', raw or '', re.M)
    if not matches:
        return None
    try:
        value = float(matches[-1].strip())
    except ValueError:
        return None
    return value if positive(value) else None


def measured_costs(records, transitions=()):
    """Compress controller costs without double-counting nested worker tools."""
    seconds = {
        'coordinator': 0.0,
        'materialization': 0.0,
        'transition_replay': 0.0,
        'other_controller_evaluation': 0.0,
        'endpoint_validation': 0.0,
    }


    counts = {key: 0 for key in seconds}
    # Preserve route and diagnostic-agent samples separately.  The legacy
    # ``coordinator`` bucket remains the disjoint accounting total, but cannot
    # projection either operation because it mixes both kinds.
    operation_seconds = {'route_model': 0.0, 'diagnostic_agent': 0.0,
                         'optimizer_finalization': 0.0}
    operation_counts = {key: 0 for key in operation_seconds}
    finalization_attempt_seconds = 0.0
    finalization_attempt_count = 0
    finalization_outcomes = {
        name: {'seconds': 0.0, 'count': 0}
        for name in ('successful_performed', 'failed_performed',
                     'cached_complete', 'cached_failed', 'unclassified')
    }
    agent_evaluations = {}
    worker_tool_seconds = 0.0
    worker_tools = 0
    interrupted_route_seconds = 0.0
    interrupted_routes = 0
    for record in records or []:
        if not isinstance(record, dict):
            continue
        value = record.get('wall_seconds')
        if not positive(value):
            continue
        kind = record.get('kind')
        bucket = None
        if kind in {'route_model', 'diagnostic_agent'}:
            bucket = 'coordinator'
            operation_seconds[kind] += value
            operation_counts[kind] += 1
        elif kind == 'optimizer_finalization':
            # This whole interval overlaps resumed-worker and evaluator/tool
            # records. Only an actually performed, completed interval predicts
            # complete finalization. Cached returns and failures remain visible
            # as censored/failed audit outcomes and never enter that mean.
            finalization_attempt_seconds += value
            finalization_attempt_count += 1
            performed = record.get('performed') is True
            cached = record.get('cached_endpoint') is True
            complete = record.get('status') == 'complete'
            if performed and not cached and complete:
                outcome = 'successful_performed'
                operation_seconds[kind] += value
                operation_counts[kind] += 1
            elif performed and record.get('status') == 'failed':
                outcome = 'failed_performed'
            elif cached and complete:
                outcome = 'cached_complete'
            elif cached and record.get('status') == 'failed':
                outcome = 'cached_failed'
            else:
                outcome = 'unclassified'
            finalization_outcomes[outcome]['seconds'] += value
            finalization_outcomes[outcome]['count'] += 1
        elif kind == 'materialization':
            bucket = 'materialization'
        elif kind == 'evaluation':
            output = str(record.get('output', ''))
            bucket = ('transition_replay' if output.startswith('transfer/')
                      else 'other_controller_evaluation')
        elif kind == 'endpoint':
            bucket = 'endpoint_validation'
        elif kind in {'agent_evaluation', 'agent_evaluation_cost'}:
            key = (record.get('visit'), record.get('trajectory'))
            # The dedicated cost record is emitted only after the full evaluator
            # footer is available, so it wins if older telemetry has the same key.
            if key not in agent_evaluations or kind == 'agent_evaluation_cost':
                agent_evaluations[key] = (value, bool(record.get('correct')))
        elif kind == 'worker_tool':
            worker_tool_seconds += value
            worker_tools += 1
        elif kind == 'interrupted_route':
            interrupted_route_seconds += value
            interrupted_routes += 1
        if bucket:
            seconds[bucket] += value
            counts[bucket] += 1
    transition_seconds = 0.0
    transition_count = 0
    for transition in transitions or []:
        if not isinstance(transition, dict):
            continue
        started, finished = transition.get('started_at'), transition.get('finished_at')
        if not positive(started) or not positive(finished):
            continue
        elapsed = finished - started
        if positive(elapsed):
            transition_seconds += elapsed
            transition_count += 1
    controller_total = sum(seconds.values())
    agent_evaluation_seconds = sum(value for value, _ in agent_evaluations.values())
    correct_agent_seconds = sum(value for value, correct in agent_evaluations.values() if correct)
    failed_agent_seconds = agent_evaluation_seconds - correct_agent_seconds
    return {
        'controller_accounted_seconds': controller_total,
        'controller_components_seconds': seconds,
        'controller_component_counts': counts,
        'historical_operation_seconds': operation_seconds,
        'historical_operation_counts': operation_counts,
        'optimizer_finalization_attempts': {
            'seconds': finalization_attempt_seconds,
            'count': finalization_attempt_count,
            'outcomes': finalization_outcomes,
            'projection_eligible': 'status=complete, performed=true, cached_endpoint=false',
        },
        'agent_evaluation_seconds': agent_evaluation_seconds,
        'agent_evaluation_count': len(agent_evaluations),
        'correct_agent_evaluation_seconds': correct_agent_seconds,
        'failed_agent_evaluation_seconds': failed_agent_seconds,
        'worker_tool_seconds': worker_tool_seconds,
        'worker_tool_count': worker_tools,
        'interrupted_route_seconds': interrupted_route_seconds,
        'interrupted_route_count': interrupted_routes,
        'transition_elapsed_seconds': transition_seconds,
        'transition_count': transition_count,
        'accounting': ('controller components are disjoint records and may be summed; '
                       'agent evaluations can be nested inside worker-tool wall time, so '
                       'agent_evaluation_seconds and worker_tool_seconds must not be added '
                       'to each other or to infer total run time; transition elapsed time '
                       'overlaps materialization and replay components and is reported '
                       'separately; optimizer_finalization is also a whole overlapping '
                       'interval and replaces, rather than adds to, its subcomponents; '
                       'interrupted routes may lack a completed route record'),
    }


def marginal_progress(current, checkpoints, eval_seconds):
    """Summarize recent measured edit yield without choosing a route.

    Baseline, final restoration and controller bookkeeping checkpoints may
    establish the incumbent, but only AKO ``[iter N]`` commits are edits in
    the recent window.  This mirrors the controller's existing three-stall
    observation horizon; it does not add a stopping or switching rule.
    """
    ordered, seen = [], set()
    for cp in sorted(checkpoints, key=lambda item: item.get('created_at', 0)):
        if (cp.get('level') != current.get('level')
                or cp.get('reference_text') != current.get('reference_text')
                or any(key in current and cp.get(key) != current[key] for key in ('visit', 'ancestry'))):
            continue
        identity = cp.get('commit') or cp.get('digest')
        if identity in seen:
            continue
        seen.add(identity)
        ordered.append(cp)

    iteration_indexes = [index for index, cp in enumerate(ordered)
                         if ITERATION_MESSAGE.search(cp.get('message', ''))]
    window_indexes = iteration_indexes[-RECENT_ATTEMPT_WINDOW:]
    if not window_indexes:
        return {
            'attempt_count': 0,
            'window_checkpoint_digests': [],
            'incumbent_before_window_ms': None,
            'best_after_window_ms': None,
            'measured_gain_percent': None,
            'material_gain_count': 0,
            'no_significant_gain_count': 0,
            'failed_attempt_count': 0,
            'measurement_unavailable_count': 0,
            'consecutive_non_material_attempts': 0,
            'low_yield_window': False,
            'evaluation_cost': None,
            'interpretation': ('No optimization-attempt window is available. This summary never proves an '
                               'optimum, a performance floor, a cause, or a required route.'),
        }

    def valid_latency(cp):
        metrics = cp.get('metrics', {})
        value = metrics.get('candidate_median_ms')
        if (metrics.get('compiled') is True and metrics.get('correctness') is True
                and positive(value)):
            return value
        return None

    first = window_indexes[0]
    prior = [valid_latency(cp) for cp in ordered[:first]]
    prior = [value for value in prior if value is not None]
    incumbent_before = min(prior) if prior else None
    running_best = incumbent_before
    material, no_significant, failed, unavailable = 0, 0, 0, 0
    consecutive_non_material = 0
    for index in window_indexes:
        cp = ordered[index]
        metrics = cp.get('metrics', {})
        value = valid_latency(cp)
        if value is None:
            if metrics.get('compiled') is False or metrics.get('correctness') is False:
                failed += 1
            else:
                unavailable += 1
            consecutive_non_material += 1
            continue
        if running_best is None:
            # Establishing the first measured incumbent is progress, but there
            # is no prior latency from which to claim a percentage gain.
            running_best = value
            consecutive_non_material = 0
            continue
        gain = max(0.0, (running_best - value) / running_best)
        if gain >= MATERIAL_GAIN_FRACTION:
            material += 1
            consecutive_non_material = 0
        else:
            no_significant += 1
            consecutive_non_material += 1
        running_best = min(running_best, value)

    gain_percent = None
    if incumbent_before is not None and running_best is not None:
        gain_percent = max(0.0, (incumbent_before - running_best) / incumbent_before * 100)
    evaluation_cost = None
    if positive(eval_seconds):
        evaluation_cost = {
            'one_evaluation_seconds': eval_seconds,
            'next_same_size_batch_evaluation_seconds': eval_seconds * len(window_indexes),
            'same_size_batch_attempts': len(window_indexes),
            'scope': ('Evaluation-only arithmetic from projected_evaluation_seconds; excludes model, '
                      'profiling, materialization and transition time.'),
        }
    return {
        'attempt_count': len(window_indexes),
        'window_checkpoint_digests': [ordered[index].get('digest') for index in window_indexes],
        'incumbent_before_window_ms': incumbent_before,
        'best_after_window_ms': running_best,
        'measured_gain_percent': gain_percent,
        'material_gain_count': material,
        'no_significant_gain_count': no_significant,
        'failed_attempt_count': failed,
        'measurement_unavailable_count': unavailable,
        'consecutive_non_material_attempts': consecutive_non_material,
        'low_yield_window': (len(window_indexes) == RECENT_ATTEMPT_WINDOW
                             and consecutive_non_material >= RECENT_ATTEMPT_WINDOW),
        'evaluation_cost': evaluation_cost,
        'interpretation': ('Latest optimization commits only; baseline, final and controller repair commits are '
                           'excluded as edits. A material gain resets the consecutive low-yield signal. Small '
                           'gains remain measured gains. This is not proof of an optimum, a performance floor, '
                           'a cause, or a required route.'),
    }


def route_outcomes(current, checkpoints, history):
    """Measured yield after a stay, relative to its pre-route branch incumbent.

Timing recovery from a regressed source is not a new search improvement. These
records describe a temporal association, not whether an edit tested the proposed
mechanism or whether the diagnosis was causal.
"""
    ordered = sorted((cp for cp in checkpoints
                      if cp.get('reference_text') == current.get('reference_text')),
                     key=lambda cp: cp.get('created_at', 0))

    def latency(cp):
        m = cp.get('metrics', {})
        value = m.get('candidate_median_ms')
        return value if m.get('compiled') is True and m.get('correctness') is True and positive(value) else None

    outcomes = []
    for index, entry in enumerate(history):
        at = entry.get('time')
        if (entry.get('action', {}).get('route') != 'stay'
                or entry.get('gate', {}).get('accepted') is not True or not positive(at)):
            continue
        origins = [cp for cp in ordered if cp.get('digest') == entry.get('checkpoint')
                   and cp.get('level') == entry.get('level') and cp.get('created_at', 0) <= at]
        if not origins:
            continue
        origin = origins[-1]
        branch = [cp for cp in ordered if all(cp.get(k) == origin.get(k)
                                             for k in ('level', 'visit', 'ancestry'))]
        before = [latency(cp) for cp in branch if cp.get('created_at', 0) <= at]
        before = [value for value in before if value is not None]
        if not before:
            continue
        until = next((h['time'] for h in history[index + 1:] if positive(h.get('time'))), float('inf'))
        attempts, seen = [], set()
        for cp in branch:
            identity = cp.get('commit') or cp.get('digest')
            if (not at < cp.get('created_at', 0) <= until or identity in seen
                    or not ITERATION_MESSAGE.search(cp.get('message', ''))):
                continue
            seen.add(identity)
            attempts.append(cp)
        values = [latency(cp) for cp in attempts]
        valid = [value for value in values if value is not None]
        incumbent = min(before)
        best_after = min(valid) if valid else None
        outcomes.append(dict(finding_id=entry['action'].get('finding_id'),
                             proposed_control=entry['action'].get('edit_op'),
                             observed_current_ms=latency(origin), pre_route_incumbent_ms=incumbent,
                             attempt_checkpoints=[cp.get('digest') for cp in attempts],
                             attempt_count=len(attempts), invalid_or_untimed_count=len(values) - len(valid),
                             best_attempt_ms=best_after,
                             gain_over_incumbent_percent=(100 * (incumbent - best_after) / incumbent
                                                          if best_after is not None else None),
                             evidence_status=('measured' if valid else 'no_valid_measurement' if attempts else 'pending'),
                             interpretation='Subsequent edits before the next review in this branch; not proof that the proposed mechanism was tested or caused the result.'))
    return outcomes[-5:]


def search_brief(current, checkpoints, profile, history, edit_chain, eval_seconds,
                 cost_records=None, transitions=(), now=None):
    from search_progress import level_coverage, progress_since_gain
    attempts, seen, best = [], set(), None
    for cp in sorted(checkpoints, key=lambda item: item.get('created_at', 0)):
        if (cp.get('level') != current.get('level')
                or cp.get('reference_text') != current.get('reference_text')
                or any(key in current and cp.get(key) != current[key] for key in ('visit', 'ancestry'))):
            continue
        identity = cp.get('commit') or cp.get('digest')
        if identity in seen:
            continue
        seen.add(identity)
        metrics = cp.get('metrics', {})
        ms = metrics.get('candidate_median_ms')
        if metrics.get('compiled') is False:
            outcome = 'compile_failed'
        elif metrics.get('correctness') is False:
            outcome = 'correctness_failed'
        elif metrics.get('compiled') is not True or metrics.get('correctness') is not True:
            outcome = 'validation_unavailable'
        elif not positive(ms):
            outcome = 'timing_unavailable'
        else:
            outcome = ('first_correct' if best is None else
                       'improved_at_least_3pct' if ms <= best * (1 - MATERIAL_GAIN_FRACTION) else
                       'smaller_gain' if ms < best else 'no_gain')
            best = min(best, ms) if best is not None else ms
        attempts.append(dict(checkpoint=cp.get('digest'), edit=cp.get('message', '')[:180],
                             outcome=outcome, candidate_ms=ms if positive(ms) else None,
                             visit=cp.get('visit'), ancestry=cp.get('ancestry'),
                             is_edit=bool(ITERATION_MESSAGE.search(cp.get('message', '')))))

    # Only use a source-bound, current, single-launch profile for this projection.
    # Warp-stall percentages never enter the calculation.
    bandwidth = None
    if profile_is_current(profile, current):
        rows = profile.get('rows', [])
        durations = [r for r in rows if r.get('metric') == 'gpu__time_duration.sum']
        throughputs = [r for r in rows if r.get('metric') == 'dram__throughput.avg.pct_of_peak_sustained_elapsed']
        if len(durations) == len(throughputs) == 1:
            duration, throughput = durations[0], throughputs[0]
            pct, ms = throughput.get('value'), duration.get('value')
            if (duration.get('unit') == 'ms' and positive(ms) and positive(pct) and pct <= 100
                    and duration.get('launch_id') is not None
                    and all(duration.get(k) == throughput.get(k) for k in
                            ('identity_namespace', 'window_id', 'forward_sample_id', 'stream', 'launch_id', 'kernel'))):
                bandwidth = dict(profile_duration_ms=ms, dram_peak_percent=pct,
                                 optimistic_same_traffic_floor_ms=ms * pct / 100,
                                 interpretation='Same traffic and clocks at peak bandwidth; not an achievable target or proof of exhaustion.')

    pending = []
    for h in history:
        execution = h.get('execution', {})
        if h.get('action', {}).get('route') == 'switch' and execution.get('status') == 'reassess_selected_endpoint':
            pending.append(dict(proposed_checkpoint=h.get('checkpoint'),
                                restored_checkpoint=execution.get('checkpoint'),
                                question=h['action'].get('args', {}).get('description'),
                                status='alternative unselected at this decision'))
    effects = []
    for edit in edit_chain:
        compiler = edit.get('compiler') or {}
        effects.append(dict(before=edit['before'], after=edit['after'],
                            changed_files=edit.get('changed_files', []),
                            same_generated_code=compiler.get('same_device_code'),
                            measurements=edit.get('measurements', {})))
    result = dict(best_measured_ms=best, checkpoint_observations=attempts[-12:],
                recent_edits=[a for a in attempts if a['is_edit']][-RECENT_EDIT_WINDOW:],
                distinct_commits=len(attempts),
                counting='Distinct measured commits, including baseline or endpoint restoration; not an iteration count.',
                full_history='ITERATIONS.md', edit_effects=effects,
                optimistic_bandwidth_bound=bandwidth, unexecuted_switches=pending[-3:],
                projected_evaluation_seconds=eval_seconds,
                recent_marginal_progress=marginal_progress(current, checkpoints, eval_seconds),
                progress_since_gain=progress_since_gain(current, checkpoints, history, now),
                level_coverage=level_coverage(current, checkpoints),
                previous_route_outcomes=route_outcomes(current, checkpoints, history),
                instruction=('Use failures to diagnose the next specific repair; require a materially different mechanism '
                             'before repeating a no-gain direction. Compare a complete next attempt with returning through '
                             'optimizer selection, restoration and endpoint validation now. AKO natural stopping remains '
                             'valid, while an outer value-stop may acknowledge unknown optimization space and stop because '
                             'the source-bound opportunity does not justify its full uncertain cost. Neither proposal alone '
                             'accepts an endpoint; the optimizer still owns selection, restoration and final validation.'))
    if cost_records is not None:
        result['measured_costs'] = measured_costs(cost_records, transitions)
    return result
