"""One hypothesis/decision from the model; provenance fields come from tools."""
from __future__ import annotations

import difflib
import json
import math
import re
from pathlib import Path

from live_routing import CONTROL_CAUSES, CONTROLS
from ours_feedback import project_stage_evidence


def optimizer_attempt_history(text, *, max_chars=16000):
    """Keep early AKO attempts visible as attributed reports, not measured proof.

    Exact log locations let the coordinator resolve truncation without reading
    every trajectory. No mechanism classification or failure cause is inferred.
    """
    lines = text.splitlines()
    starts, invocation = [], None
    for index, line in enumerate(lines):
        if re.match(r"^# Invocation\s+", line):
            invocation = line.lstrip("# ").strip()
        elif re.match(r"^#{2,6}\s+(?:Iter(?:ation)?\s*\d+|Baseline\b|Final\b)", line, re.I):
            starts.append((index, invocation))
    attempts, remaining, omitted = [], max_chars, 0
    for ordinal, (start, invocation) in enumerate(starts):
        end = starts[ordinal + 1][0] if ordinal + 1 < len(starts) else len(lines)
        report = []
        for offset in range(start + 1, end):
            line = lines[offset].strip()
            if re.match(r"^-?\s*(?:\*\*)?(?:Hypothesis|Changes|Analysis|Compiled|Correct(?:ness)?|Runtime|Status|Result|Bench)\b", line, re.I):
                # Include the outcome even when a long hypothesis precedes it.
                report.append(dict(line=offset + 1, text=line[:220], truncated=len(line) > 220))
        item = dict(invocation=invocation, title=lines[start].lstrip("# "),
                    source=dict(path="ITERATIONS.md", start_line=start + 1, end_line=end),
                    optimizer_report=report)
        size = len(json.dumps(item, ensure_ascii=False))
        if size > remaining:
            omitted += 1
            continue
        attempts.append(item)
        remaining -= size
    return dict(attempts=attempts, total_attempts=len(starts), omitted_attempts=omitted,
                complete=omitted == 0 and bool(starts), source="ITERATIONS.md",
                interpretation=("Historical original-optimizer reports, not fresh observations or verified causes. "
                                "Read linked outputs to validate claims. Missing/truncated history does not mean untested. "
                                "A retry must identify the prior attempt and explain what changed that could alter its outcome; "
                                "failure of one configuration does not rule out the whole mechanism."))


def restoration_options(current, endpoints, visit):
    """Expose same-session selected endpoints without making a failed source exportable."""
    selected = endpoint_summary(current, endpoints)['validated']
    options = []
    for item in selected:
        cp = endpoints[item['key']]
        if (item['matches_current_source'] or cp.get('level') != current.get('level')
                or cp.get('visit') != visit or cp.get('ancestry') != current.get('ancestry')):
            continue
        options.append(dict(key=item['key'], checkpoint=item['checkpoint'],
                            object_id=f"{cp['level']}:selected-endpoint:{item['key']}",
                            level=cp['level'], candidate_median_ms=item['candidate_median_ms']))
    return dict(options=options, required_first_action='verify/replay selected endpoint object',
                conditional_path=['original optimizer selection/restoration and full validation',
                                  'reassess restored source', 'export and source/artifact replay',
                                  'target optimizer startup/search/evaluation and eventual finish'],
                cost_reference='search.action_costs.options.switch',
                additional_cost='restored-source route reassessment; amount unknown until measured',
                interpretation=('These are historical validated selections, not fresh evidence for the current source. '
                                'Restore through the original optimizer; keep Native guards unchanged until source/export replay passes. '
                                'Include the complete conditional path cost, without counting source finalization twice. '
                                'Restoration permits reassessment, not automatic approval of a switch.'))


def _failed_observation(observation):
    return (observation.get("kind") in {"compile", "correctness"}
            and observation.get("value") is False)


def _useful_measurement(observation):
    if observation.get("kind") not in {"latency", "profile"}:
        return False
    value = observation.get("value")
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
        return False
    return observation.get("kind") != "latency" or value > 0


def _prioritized_observations(observations):
    failures = [observation for observation in observations if _failed_observation(observation)]
    measurements = [observation for observation in observations if _useful_measurement(observation)]
    if failures or measurements:
        return failures + measurements
    return [observation for observation in observations
            if observation.get("kind") not in {"latency", "profile"}]


def decision_schema(context):
    """Encode route invariants before generation; the gate still verifies them."""
    def obj(fields):
        return {"type": "object", "additionalProperties": False,
                "required": list(fields), "properties": fields}
    text = {"type": "string"}
    common = {
        "evidence_ids": {"type": "array", "minItems": 1,
                         "items": {"enum": [e["id"] for e in context["evidence"]]}},
        "hypothesis": text, "question": text, "expected_metric": text,
        "stop_reason": text, "confidence": {"type": "number", "minimum": 0, "maximum": 1},
    }
    if context.get("shared_feedback_contract"):
        # Model judgments accompany the existing wire action/finding as a sidecar.
        # A hypothesis falsifier is distinct from the stop condition.
        common.update(source_checkpoint={"enum": [context["checkpoint"]]},
                      prediction=text, disconfirm_if=text, alternative_actions=text)
        ids = [item['hypothesis']['id'] for item in context.get('hypothesis_history', [])]
        common['hypothesis_assessments'] = {
            'type': 'array', 'maxItems': len(ids),
            'items': obj({'hypothesis_id': {'enum': ids or ['unavailable']},
                          'before': text, 'after': text,
                          'implementation_status': {'enum': ['executed', 'not_implemented', 'unknown']},
                          'judgment': {'enum': ['supported', 'refuted', 'inconclusive', 'not_tested']},
                          'rationale': text, 'test_evidence': text})}
    active = context["level"]
    branches = []
    for route in ("stay", "switch", "verify", "stop"):
        levels = [active] if route in {"stay", "verify"} else ["High", "Native"]
        targets = [obj({"level": {"enum": [level]},
                        "object_id": {"enum": [o["id"] for o in context["objects"] if o["level"] == level
                                                 and (route == 'verify' or not o.get('restoration_only'))]}})
                   for level in levels if any(o["level"] == level for o in context["objects"])]
        operations = ({"profile", "mapping", "replay"} if route == "verify" else
                      {"stop"} if route == "stop" else set(CONTROLS[active]) if route == "stay" else
                      set(CONTROL_CAUSES))
        unknown = context.get("evaluation_status", {})
        unavailable_causes = {cause for cause, key in
                              (("compile_error", "compiled"), ("numerical_mismatch", "correctness"))
                              if unknown.get(key) == "unknown"}
        mechanisms = []
        for op in sorted(operations):
            causes = CONTROL_CAUSES.get(op, set.union(*CONTROL_CAUSES.values())) - unavailable_causes
            if causes:
                mechanisms.append(obj({"edit_op": {"enum": [op]}, "cause_class": {"enum": sorted(causes)}}))
        branches.append(obj({**common, "route": {"enum": [route]},
                             "targets": {"type": "array", "minItems": 0 if route == "stop" else 1,
                                         "items": {"anyOf": targets}},
                             "mechanism": {"anyOf": mechanisms}}))
    # A nested union works with structured output; the root remains an object.
    return obj({"decision": {"anyOf": branches}})


def localize_proofs(context, root, directory):
    """Copy controller-owned provenance into the isolated read-only evidence set."""
    relations = []
    for relation in context.get("relations", []):
        item = dict(relation)
        proof = Path(str(item.get("proof", "")))
        if proof.is_absolute() and proof.resolve().is_relative_to(Path(root).resolve()) and proof.is_file():
            data = proof.read_bytes()
            size = len(data)
            relative = "provenance/record-" + str(len(relations)) + proof.suffix
            target = Path(directory) / relative
            target.parent.mkdir(exist_ok=True)
            if not target.exists():
                target.write_bytes(data)
            elif target.read_bytes() != data:
                raise ValueError("Localized proof changed")
            target.chmod(0o444)
            item.update(proof=relative, proof_bytes=size)
        elif proof.is_absolute():
            # The original remains in the controller's immutable context. Do not
            # advertise an inaccessible host path as readable agent evidence.
            item.update(proof="controller-attested:unavailable-in-workspace", proof_available=False)
        relations.append(item)
    return relations


def route_brief(request, directory):
    """Only new cross-layer observations; no history/source/cost retelling."""
    brief = {key: request.get(key) for key in (
        "checkpoint", "level", "correct", "evaluation_status", "task_contract",
        "objects", "relations", "evidence", "stage_evidence", "evaluation_stage_evidence",
        "attribution")}
    brief["files"] = {key: request.get(key) for key in ("compiler_artifacts", "comparison_files")}
    if request.get('native_source_files'):
        brief['files']['native_source_files'] = request['native_source_files']
        brief['files']['native_source_base'] = 'current workspace root, not this measurement directory'
    stages = request.get('evaluation_stage_evidence') or {}
    if (stages.get('version') in {'cuda-suite-stage-observations-v1', 'ascend-suite-stage-observations-v1'}
            and (directory / 'request.json').is_file()):
        # The full rows stay in request.json. Show every measured sample once,
        # without repeating program ownership and schema fields for each launch.
        brief['evaluation_stage_evidence'] = {
            key: stages.get(key) for key in ('version', 'status', 'current', 'issues', 'headroom')}
        brief['evaluation_stage_evidence'].update(
            full_record='request.json#/evaluation_stage_evidence',
            row_columns=['launch_id', 'kernel', 'ms', 'share_of_device_work', 'evidence_id',
                         'source_object_id'],
            source_mapping=('device entry symbol join; see attribution'
                            if (request.get('attribution') or {}).get('status') == 'attributed'
                            else 'unresolved; launch order/name is not a source mapping'),
            samples=[dict(seed=sample['seed'], sample=sample['sample'],
                          device_work_ms=sample['reported_device_task_sum_ms'],
                          rows=[[row.get('launch_id'), row.get('kernel'), row['value'],
                                 row.get('share_of_observed_device_duration'), row.get('evidence_id'),
                                 row.get('source_object_id')]
                                for row in sample['rows']]) for sample in stages.get('samples', [])])
        brief['evidence'] = [item for item in brief.get('evidence', [])
                             if item.get('evidence_channel') != 'evaluation_stage_evidence']
    return brief


def endpoint_summary(current, endpoints):
    """Expose controller-validated optimizer selections, not measured-best telemetry."""
    valid = []
    for key, cp in endpoints.items():
        metrics = cp.get("metrics", {})
        ms = metrics.get("candidate_median_ms")
        if (cp.get("selected_by") != "ako_worker"
                or cp.get("reference_text") != current.get("reference_text")
                or metrics.get("compiled") is not True or metrics.get("correctness") is not True
                or not isinstance(ms, (int, float)) or isinstance(ms, bool)
                or not math.isfinite(ms) or ms <= 0):
            continue
        valid.append(dict(key=key, checkpoint=cp["digest"], level=cp["level"],
                          commit=cp.get("commit"), candidate_median_ms=ms,
                          selected_by="ako_worker", validated=True,
                          matches_current_source=(cp["digest"] == current["digest"]
                              and cp.get("source_files") == current.get("source_files")
                              and cp["level"] == current["level"])))
    return dict(validated=valid, current_source_has_selected_endpoint=any(
        cp["matches_current_source"] for cp in valid),
        stopping_rationale_file="ITERATIONS.md",
        interpretation=("A validated optimizer-selected endpoint is available; this does not prove a floor or exhausted directions."
                        if valid else
                        "No optimizer-selected endpoint is recorded yet. With a validated correct incumbent and justified stopping rationale, "
                        "a stop proposal can ask the original optimizer to select, restore and validate its endpoint."))


def bind_decision(proposal, context):
    """Bind only known measurements/objects. Never invent a mapping or observation."""
    records = {e["id"]: e for e in context["evidence"]}
    objects = {o["id"]: o for o in context["objects"]}
    evidence = [records[key] for key in proposal["evidence_ids"]]
    if not evidence:
        raise ValueError("Decision needs an acquired observation")
    missing_cause = {"compile_error": "compiled", "numerical_mismatch": "correctness"}.get(proposal["cause_class"])
    if missing_cause and context.get("evaluation_status", {}).get(missing_cause) == "unknown":
        raise ValueError("Missing evaluation result cannot establish " + proposal["cause_class"])
    if (context.get("shared_feedback_contract")
            and proposal.get("source_checkpoint") != context.get("checkpoint")):
        raise ValueError("Decision hypothesis is not bound to the current source checkpoint")
    targets = proposal["targets"]
    for target in targets:
        if objects[target["object_id"]]["level"] != target["level"]:
            raise ValueError("Target object belongs to a different representation")
        if objects[target["object_id"]].get('restoration_only'):
            if proposal['route'] != 'verify' or proposal['edit_op'] != 'replay' or len(targets) != 1:
                raise ValueError('Historical endpoint permits only a single restoration replay target')
    # For stop, targets may identify the endpoint the model is discussing;
    # they are not continuation levels in the routing action contract.
    levels = []
    if proposal["route"] != "stop":
        # Targets identify concrete editable objects, so a decision may cite
        # several objects in one representation (for example a Native kernel
        # and its program call graph).  The routing action, however, carries
        # representation preferences. Preserve the proposal order while
        # canonicalizing those preferences to one entry per level.
        for target in targets:
            if target["level"] not in levels:
                levels.append(target["level"])
    observation = evidence[0]["observation"]
    if context.get("compact_feedback_evidence"):
        preferred = _prioritized_observations([record["observation"] for record in evidence])
        if not preferred:
            raise ValueError("Decision needs a usable acquired observation")
        observation = preferred[0]
    object_id = targets[0]["object_id"] if targets else observation["object_id"]
    action = dict(route=proposal["route"], target_levels=levels, edit_op=proposal["edit_op"],
                  args=dict(object_id=object_id, description=proposal["question"]),
                  finding_id=context["finding_id"], expected_metric=proposal["expected_metric"],
                  stop_if=proposal["stop_reason"])
    controls = [dict(level=t["level"], name=proposal["edit_op"], args=dict(object_id=t["object_id"]),
                     preconditions=["fresh_evidence", "mapped_object", "task_abi"])
                for t in targets if proposal["edit_op"] in CONTROLS[t["level"]]]
    finding = dict(checkpoint=context["checkpoint"], observation=observation,
                   cause={"class": proposal["cause_class"], "object_id": object_id, "relation": "observes"},
                   controls=controls,
                   evidence=[dict(source=e["observation"]["source"], id=e["id"], relation="observes", freshness="fresh")
                             for e in evidence],
                   action=dict(levels=levels, confidence=proposal["confidence"], rationale=proposal["hypothesis"]),
                   status="verify" if proposal["route"] == "verify" else "supported")
    if context.get("shared_feedback_contract"):
        # Keep the hard-gate schema unchanged; the full hypothesis is diagnostic.
        from ours_hypothesis import hypothesis_record
        context["active_hypothesis"] = hypothesis_record(action, finding, context, proposal)
    return action, finding


def feedback_card(action, finding, context, level=None):
    """Diagnostic evidence and a falsifiable question; AKO owns implementation."""
    level = level or context["level"]
    observation = finding["observation"]
    objects = {o["id"]: o for o in context["objects"]}
    obj = objects.get(action["args"]["object_id"], {})
    location = obj.get("span") if obj.get("level") == level else "solution/ModelNew.py:forward"
    if isinstance(location, dict):
        location = f"{location.get('file', 'solution/ModelNew.py')}:{location.get('line', 1)}"
    # Generated artifact locations are not the optimizer's editable source on a revisit.
    if not location or (level == "High" and "solution/" not in str(location)):
        location = "solution/ModelNew.py:forward"
    observation_text = f"{observation['metric']} = {observation['value']} {observation['unit']}"
    if context.get("compact_feedback_evidence"):
        records = {record["id"]: record["observation"] for record in context["evidence"]}
        cited = [records[record["id"]] for record in finding["evidence"] if record["id"] in records]
        selected = _prioritized_observations(cited)
        facts = []
        seen = set()
        for record in selected:
            fact = (record.get("metric"), record.get("value"), record.get("unit"))
            if fact in seen:
                continue
            seen.add(fact)
            facts.append(f"{fact[0]} = {fact[1]} {fact[2]}")
            if len(facts) == 3:
                break
        if facts:
            observation_text = "; ".join(facts)
    card = (f"Observation: {observation_text}.\n"
            f"Location: {location}\n"
            f"Question: {action['args']['description']} Expected measurement: {action['expected_metric']}. "
            "Choose the implementation yourself and follow the original AKO skill.\n")
    if context.get("shared_feedback_contract"):
        hypothesis = context.get("active_hypothesis", {})
        card += (f"Hypothesis (unverified): {finding['action']['rationale']}\n"
                 f"Control: {action['edit_op']}; evidence IDs: "
                 + ", ".join(record['id'] for record in finding['evidence']) + "\n"
                 f"Disconfirm if: {hypothesis.get('disconfirm_if') or 'unspecified; do not claim a causal test from timing alone'}.\n"
                 f"Hypothesis ID: {hypothesis.get('id', 'unrecorded')}. "
                 "You may reject this premise or choose another edit. In ITERATIONS.md, state whether "
                 "the edit actually tests this hypothesis, with its before/after commits and measured outcome.\n")
        records = {record['id']: record for record in context['evidence']}
        identities = [{key: records[ref['id']].get(key) for key in
                       ('id', 'measurement_identity', 'aggregation', 'source_mapping')}
                      for ref in finding['evidence'] if ref['id'] in records
                      and records[ref['id']].get('measurement_identity')]
        if identities:
            card += "Observed launch identities (source mapping may be unresolved): " + json.dumps(identities, separators=(',', ':')) + "\n"
    return card


def changes(before, after, before_export=None, after_export=None):
    """Exact source/compiler deltas and observed timings, not causal conclusions."""
    changed, diff = [], []
    for name in sorted(set(before["source_files"]) | set(after["source_files"])):
        if before["source_files"].get(name) == after["source_files"].get(name):
            continue
        changed.append(name)
        old, new = Path(before["path"]) / "solution" / name, Path(after["path"]) / "solution" / name
        diff.extend(difflib.unified_diff(old.read_text(errors="replace").splitlines() if old.exists() else [],
                    new.read_text(errors="replace").splitlines() if new.exists() else [],
                    fromfile="before/" + name, tofile="after/" + name, lineterm=""))
    result = {"before": before["digest"], "after": after["digest"], "historical_only": True,
              "edits": [before.get("message"), after.get("message")], "changed_files": changed,
              "source_diff": "\n".join(diff)[:20000],
              "measurements": {"before": before.get("metrics"), "after": after.get("metrics")},
              "compiler": None}
    if before_export and after_export:
        old, new = before_export.get("kernels", []), after_export.get("kernels", [])
        generated_diff = []
        for name in sorted({k["source"] for k in old} | {k["source"] for k in new}):
            a, b = Path(before["path"]) / "generated" / name, Path(after["path"]) / "generated" / name
            generated_diff.extend(difflib.unified_diff(
                a.read_text(errors="replace").splitlines() if a.exists() else [],
                b.read_text(errors="replace").splitlines() if b.exists() else [],
                fromfile="before/" + name, tofile="after/" + name, lineterm=""))
        result["compiler"] = {"diff": "\n".join(generated_diff)[:20000], "same_device_code": [k.get("device_text") for k in old] == [k.get("device_text") for k in new],
            "before": [{k: row.get(k) for k in ("callsite", "device_text", "pass_configs", "native_span")} for row in old],
            "after": [{k: row.get(k) for k in ("callsite", "device_text", "pass_configs", "native_span")} for row in new],
            "semantics": "Ordered compiler artifacts of these sources; unchanged output alone does not prove a representation limit."}
    return result
