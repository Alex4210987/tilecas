# ROCm evaluation source

The evaluator checks 30 correctness inputs and uses three warmups followed by five timed forward calls. The latency statistic is the median. Reference and candidate use the same input settings and HIP event boundaries.
