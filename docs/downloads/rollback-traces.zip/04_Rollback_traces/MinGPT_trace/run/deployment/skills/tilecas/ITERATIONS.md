# Iterations

Keep one concise entry per measured candidate, including failures; number across levels.
Record: exact code parent, level, idea and expected effect, full-suite result, latency and keep/revise/reject decision.
Include the relevant trajectory and Git references. Distinguish measured improvement from timing variation and expected future benefit.
Record diagnostic findings only when used; identify missing evidence or uncertain explanations.

## Level changes and branches

Record the retained High parent, unchanged export or exact restored node, and the reason for changing level.
Distinguish structural changes, local tuning and representation transfers. Keep the best validated candidate separate from the active exploration branch.

## Final selection

Record the chosen node, final validation and reason for stopping. Leave the complete selected source at HEAD.
