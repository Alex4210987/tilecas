# Seed-level results and resampling details

The endpoint table contains 11,000 rows: 11 methods or variants × 50 workloads × four accelerator–model configurations × five runs. Agent seed labels are 101, 211, 307, 401, and 503. `run_id` links endpoint and timing tables. Figure 6 plotting inputs are indexed separately in `../WEBSITE_CONTENTS.md`.

| File | Contents |
|---|---|
| `all_modes_5repeat_endpoints.csv` | Per-run correctness, endpoint speedup, first-correct cost, elapsed time, and evaluation count |
| `timing_samples.csv` | Reference and candidate timing samples, platform metric, input parameters, and tolerances |
| `reference_baselines.csv` | Reference latency by platform and workload |
| `five_repeat_means.csv` | Seed-level aggregate results |
| `all_modes_summary.csv` | Per-configuration and overall endpoint summaries for Table 1 |
| `win_tie_loss.csv` | Table 2 paired outcomes using majority correctness and the 3% tie threshold |
| `first_correct_summary.csv` | Table 3 first-correct cost and success denominators |
| `ablation_results.csv` | Table 4 component ablations |
| `correctness_distribution.csv` | Number of correct runs per workload–configuration pair |
| `pair_cv_summary.csv`, `pooled_cv_summary.csv` | Endpoint CV summaries and zero-mean exclusions |
| `paired_workload_effects.csv`, `paired_effect_intervals.csv` | Paired workload effects and confidence intervals |
| `resampling_details.json` | Bootstrap unit, pairing, random seed, draws, and percentile convention |

Bootstrap draws resample 50 workloads with replacement, retaining each workload's four configurations and five runs. The same workload indices are used across methods. There are 20,000 draws with seed 2026100431; interval endpoints are the 2.5th and 97.5th percentiles with linear interpolation. Standard deviation uses the five aggregate seed means and ddof=1.

Timing records contain five samples per successful role after three warm-ups. Failed attempts keep their correctness status. First-correct means use successful runs; majority success and endpoint aggregation retain their separate denominators.

The pooled endpoint CV distribution includes all 11 methods: 2,138 nonzero method–workload–configuration pairs, with 62 all-zero pairs excluded. The median is 2.20% and P90 is 3.99%. Every pair has equal weight. Each pair CV is 100 × sample SD / mean over its five endpoint scores (ddof=1), including failed-run zeros. Per-method CV summaries remain separate.

`timing_samples.csv` uses `evaluator_latency_ms` as its shared latency field and `evaluator_metric` for the metric name. The `full_forward_elapsed_ms` field is populated for AMD and blank for Ascend. Platform timing boundaries are described in `../00_paper_protocol/CORRECTNESS_AND_TIMING.md`.

The endpoint convention is **best reported**, defined in `../00_paper_protocol/ENDPOINT_DEFINITION.md`. Each eligible evaluation uses a five-call median under a fixed reference; final verification is recorded separately.

## Final verification

The `final_verify` columns contain measured final-verification speedups. Original endpoint results and their confidence intervals retain their own columns. `FINAL_VERIFICATION.md` describes the final result files, paired comparisons, and the separate MinGPT Figure 4 case.
